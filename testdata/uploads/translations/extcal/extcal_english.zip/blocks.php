<?php

define('_MB_EXTCAL_BGCOLOR', 'Background color');
define('_MB_EXTCAL_CAT_TO_USE', 'Category');
define('_MB_EXTCAL_HEIGHT', 'Height');
define('_MB_EXTCAL_HORLOGE', 'Clock');
define('_MB_EXTCAL_HORLOGE_OPT', 'Clocks options');
define('_MB_EXTCAL_OPT_SHOW', 'Show options');
define('_MB_EXTCAL_OPT_SLIDE_SHOW', 'Slide show');
define('_MB_EXTCAL_WIDTH', 'Width');
define('_MB_EXTCAL_ALL_CAT', 'All categories');
define('_MB_EXTCAL_CAT_TO_USE_DESC', 'Select category where event are picked');
define('_MB_EXTCAL_CURRENT', 'Current');
define('_MB_EXTCAL_DISPLAY', 'Display');
define('_MB_EXTCAL_DISPLAY_IMG', 'Display Image');
define('_MB_EXTCAL_DISPLAY_MONTH', 'Month to be displayed');
define('_MB_EXTCAL_DISPLAY_SUBMIT_LINK', 'Display submit link');
define('_MB_EXTCAL_EVENT', 'events');
define('_MB_EXTCAL_IMG_CAT', 'Image category');
define('_MB_EXTCAL_NEXT', 'Next');
define('_MB_EXTCAL_PREVIEW', 'Preview');
define('_MB_EXTCAL_PX', 'px');
define('_MB_EXTCAL_SECONDES', 'seconds');
define('_MB_EXTCAL_SS_HEIGHT', 'Slideshow height');
define('_MB_EXTCAL_SS_NB_PHOTOS', 'Slideshow # of photos');
define('_MB_EXTCAL_SS_PAUSE_TIME', 'Slideshow pause time');
define('_MB_EXTCAL_SS_TRANS_TIME', 'Slideshow transition time');
define('_MB_EXTCAL_SS_WIDTH', 'Slideshow width');
define('_MB_EXTCAL_SUBMIT_LINK_TEXT', 'Submit event');
define('_MB_EXTCAL_TITLE_LENGTH', 'Title length');
//2.37
define('_MB_EXTCAL_UPCOMING_DAYS', '# of Days to Include in Search');
