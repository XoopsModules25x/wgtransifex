<?php
//
// _LANGCODE: fr
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

$supports = array();

// Site d'assistance en anglais
$supports['english'] = array(
'url' => 'http://www.xoops.org/',
'title' => 'English support');

// Ajouter des sites de soutien supplémentaires, utilisez le nom du dossier de langue correspondante comme clé, par exemple:
/*
$supports["french"] = array(
"url"   => "http://www.frxoops.org/",
"title" => "Support francophone"
);
*/