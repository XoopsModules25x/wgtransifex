tinyMCE.addI18n('fr.xoopscode',{
    code_desc:"Insérer le code"
});