<?php
/**
* Adapté de la licence sous GPL 1 ou supérieure
* http://search.cpan.org/~creamyg/Lingua-StopWords-0.09/
 */
define(
    '_XMF_STOPWORDS',
    "je moi mon moi-même nous nos nous-mêmes toi ton tiens toi-même "
    . "vous-mêmes il lui son lui-même elle sa sienne elle-même son sien "
    . . "lui-même ils eux leur leurs eux-mêmes quel lequel qui à qui "
    . "ce que ces ceux suis est sont fut étiez être été étant avoir a "
    . "avait avoir faire fait fit faisant aurais devrais pourrais faut je suis "
    . "tu es il est elle est c'est nous sommes ils sont j'ai vous avez nous avons ils ont "
    . "j'aurais tu aurais il aurait elle aurait nous aurions ils auraient je vais tu vas il va elle va nous allons "
    . "ils vont n'est pas ne sont pas n'était pas n'étaient pas n'a pas n'ont pas n'ont pas eu "
    . "ne fait pas ne peut pas ne sera pas ne serait pas ne doit pas ne devrait pas ne peut pas "
    . "ne peut pas ne pouvait pas ne doit pas allons c'est qui est quel est voici "
    . "Il y a quand-est-ce où-est-ce pourquoi comment-est-ce un un le et mais si ou "
    . "car comme jusqu'à tandis-que de à par pour avec sur contre entre "
    . "dans par pendant avant après au-dessus au-dessous-de à de en-haut vers-le bas dans "
    . "en-dehors sur de plus-de en-dessous-de encore plus-loin puis une-fois-que ici Là quand "
    . "où pourquoi comment tous tout tous-les-deux chaque peu plus le-plus autre certains tel "
    . "non ni ne-pas seulement propre même alors que aussi très"
);