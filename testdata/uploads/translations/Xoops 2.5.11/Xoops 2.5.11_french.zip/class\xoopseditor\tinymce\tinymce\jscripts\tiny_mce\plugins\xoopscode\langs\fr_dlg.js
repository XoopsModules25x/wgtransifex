tinyMCE.addI18n('fr.xoopscode_dlg',{
xoopscode_title:"Insérer du code",
xoopscode_desc:"Insérer du code",
xoopscode_sub:"Collez le code que vous souhaitez insérer dans la case ci-dessous:"
});