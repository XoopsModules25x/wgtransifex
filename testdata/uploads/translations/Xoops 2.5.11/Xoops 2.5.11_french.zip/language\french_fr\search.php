<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
//%%%%%%    File Name search.php    %%%%%
define('_SR_SEARCH', 'Recherche');
define('_SR_PLZENTER', 'Veuillez entrer toutes les données requises !');
define('_SR_SEARCHRESULTS', 'Résultats de la recherche');
define('_SR_NOMATCH', 'Aucune correspondance trouvée pour votre requête');
define('_SR_FOUND', '<strong>%s</strong> correspondance(s) trouvée(s)');
define('_SR_SHOWING', '(%d -%d affichés)');
define('_SR_ANY', 'Quelques uns (OU)');
define('_SR_ALL', 'Tous (ET)');
define('_SR_EXACT', 'Correspondance exacte');
define('_SR_SHOWALLR', 'Afficher tous les résultats');
define('_SR_NEXT', 'Suivant >>');
define('_SR_PREVIOUS', '<< Précédent');
define('_SR_KEYWORDS', 'Mots clés');
define('_SR_TYPE', 'Type');
define('_SR_SEARCHIN', 'Rechercher dans');
define('_SR_KEYTOOSHORT', 'Les mots clés doivent contenir au moins <strong>%s</strong> caractères');
define('_SR_KEYIGNORE', 'Les mots-clés d\'une longueur inférieure à <strong>%s</strong> caractères seront ignorés');
define('_SR_SEARCHRULE', 'Règles de recherche');
define('_SR_IGNOREDWORDS', 'Les mots suivants sont plus courts que le minimum de la longueur permise (%u signes) et n\'étaient pas inclus dans votre recherche :');
