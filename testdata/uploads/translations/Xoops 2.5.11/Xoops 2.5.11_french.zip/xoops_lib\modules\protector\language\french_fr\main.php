<?php
define('_MD_PROTECTOR_YOUAREBADIP', 'Vous êtes enregistré comme BAD_IP par Protector.<br />');
define('_MD_PROTECTOR_FMT_JAILINFO', 'Cette restriction expirera le %s');
define('_MD_PROTECTOR_FMT_JAILTIME', 'j-m-Y H:i:s');
define('_MD_PROTECTOR_BANDWIDTHLIMITED', 'Ce site est très chargé actuellement. Veuillez essayer plus tard.');
define('_MD_PROTECTOR_TURNJAVASCRIPTON', 'Activez JavaScript');
define('_MD_PROTECTOR_DENYBYRBL', 'Protector rejette votre envoi, car votre adresse IP est enregistrée dans la liste noire.');
define('_MD_PROTECTOR_FMT_REGISTER_MORATORIUM', 'Retentez d\'envoyer votre message dans %s minutes (protection anti-spam, désolé).');
