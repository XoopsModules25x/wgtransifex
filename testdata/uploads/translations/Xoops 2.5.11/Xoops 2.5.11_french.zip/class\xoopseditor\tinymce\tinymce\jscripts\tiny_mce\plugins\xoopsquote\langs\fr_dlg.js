tinyMCE.addI18n('fr.xoopsquote_dlg',{
xoopsquote_title:"Insérer une citation",
xoopsquote_desc:"Insérer une citation",
xoopsquote_sub:"Collez la citation que vous souhaitez insérer dans la case ci-dessous :"
});