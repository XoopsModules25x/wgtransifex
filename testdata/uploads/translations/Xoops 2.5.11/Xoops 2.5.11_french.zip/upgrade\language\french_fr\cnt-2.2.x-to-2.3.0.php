<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_CONFIRM_UPGRADE_220', "
Les scripts de mise à niveau permettront de migrer les données du module 'profile' existant. <br>
Veuillez ne pas désinstaller manuellement le module 'profile' existant, sinon les données correspondantes ne seront pas migrées. <br><br>
Une fois le processus de mise à niveau terminé, <strong>veuillez vous rendre dans la zone d'administration du module pour mettre à jour le module 'profile'</strong>  Une fois cette opération effectuée, les données du profil seront complètement migrées.<br><br>
Pour annuler la mise à niveau, <a href='index.php'>cliquez ici </a>.<br><br>
Ou <a style='color:green; font-size:1.3em;' href='index.php?action=next&upd220=ok'>procéder</a>.
");
