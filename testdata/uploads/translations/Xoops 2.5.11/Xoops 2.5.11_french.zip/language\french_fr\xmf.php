<?php

define('_AM_XMF_MODULE_NOTFOUND','Veuillez installer ou réactiver le module %1$s. Version minimum requise : %2$s');
define('_AM_XMF_MODULE_VERSION','Version minimum du module %1$s requise : %2$s (votre version est la %3$s)');
define('_AM_XMF_MODULE_INSTALLED', 'Le module \'%s\' est installé !');
define('_AM_XMF_MODULE_NOT_INSTALLED', 'Le module \'%s\' n\'est pas installé !');

define('_DB_XMF_TABLE_IS_NOT_DEFINED','La table n\'est pas définie');
