tinyMCE.addI18n('fr.example',{
desc: "Ceci est juste un bouton de modèle"
});