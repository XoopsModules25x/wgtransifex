/**
 */

tinyMCE.addI18n('fr.xoopsimagemanager',{
    desc : 'Gestionnaire avancé\_d'images Xoops',
    delta_width : '0',
    delta_height : '0'
});
tinyMCE.addI18n('fr.xoopsimagebrowser',{
    desc : 'Navigateur d'images Xoops',
    delta_width : '0',
    delta_height : '0'
});