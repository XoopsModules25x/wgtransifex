<?php
// _LANGCODE: fr
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('LEGEND_XOOPS_PATHS', 'Chemin physique de XOOPS');
define('LEGEND_DATABASE', 'Jeu de caractères de la base de données');

define('XOOPS_LIB_PATH_LABEL', 'Répertoire de la bibliothèque XOOPS');
define('XOOPS_LIB_PATH_HELP', 'Chemin physique vers le répertoire de la bibliothèque XOOPS SANS barre oblique, pour la compatibilité ascendante. Localisez le dossier à l\'extérieur de ' . XOOPS_ROOT_PATH . pour le sécuriser") ;
define('XOOPS_DATA_PATH_LABEL', 'Répertoire de la bibliothèque XOOPS') ;
define('XOOPS_DATA_PATH_HELP', 'Chemin physique vers le répertoire des fichiers de données XOOPS (inscriptibles) SANS barre oblique, pour la compatibilité ascendante. Localisez le dossier à l\'extérieur de ' . XOOPS_ROOT_PATH . pour le sécuriser") ;

define('DB_COLLATION_LABEL', 'Database character set and collation') ;
define('DB_COLLATION_HELP', "A partir de la version 4.12, MySQL supporte les jeux de caractères personnalisés et la collation. Cependant, il est plus complexe que prévu, donc NE FAITES PAS de changement à moins d/'être sûr de votre choix") ;
define('DB_COLLATION_NOCHANGE', 'Ne pas changer') ;

define('XOOPS_PATH_FOUND', 'Chemin trouvé.') ;
define('ERR_COULD_NOT_ACCESS', 'Impossible d/'accéder au dossier spécifié. Veuillez vérifier qu/'il existe et qu/'il est lisible par le serveur") ;
define('CHECKING_PERMISSIONS', 'Vérifier les permissions des fichiers et des répertoires...') ;
define('ERR_NEED_WRITE_ACCESS', 'Le serveur doit avoir un accès en écriture aux fichiers et dossiers suivants <br>(i.e. <em>chmod 777 directory_name</em> on a UNIX/LINUX server)');
define('IS_NOT_WRITABLE', '%s n/'est PAS inscriptible.*.') ;
define('IS_WRITABLE', '%s est inscriptible.*.');
define('ERR_COULD_NOT_WRITE_MAINFILE', 'Erreur d'écriture du contenu dans mainfile.php, écrire le contenu dans mainfile.php manuellement.');