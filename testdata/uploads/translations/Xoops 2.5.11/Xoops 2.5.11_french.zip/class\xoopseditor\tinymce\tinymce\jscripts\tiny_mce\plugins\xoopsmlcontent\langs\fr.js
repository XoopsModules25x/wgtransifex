/**
 */

tinyMCE.addI18n('fr.xoopsmlcontent',{
desc : 'Inserer du contenu multi-langage',
delta_width : '0',
delta_height : '0'
});