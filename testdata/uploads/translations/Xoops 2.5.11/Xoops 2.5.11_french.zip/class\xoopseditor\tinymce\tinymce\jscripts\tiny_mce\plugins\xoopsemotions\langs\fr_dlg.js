/**
 */

tinyMCE.addI18n('fr.xoopsemotions_dlg',{
title : 'Insérer des émoticônes Xoops',
tab_emotionsbrowser: 'Émoticônes',
tab_emotionsadmin: 'Ajouter des émoticônes',
error_noemotions: 'Aucune émoticône dans la base de données !!!'
});