<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AD_NORIGHT', 'Vous n\'avez pas la permission d\'accéder à cette zone');
define('_AD_ACTION', 'Action');
define('_AD_EDIT', 'Modifier');
define('_AD_DELETE', 'Effacer');
define('_AD_LASTTENUSERS', 'Les 10 derniers membres inscrits');
define('_AD_NICKNAME', 'Pseudo');
define('_AD_EMAIL', 'Courriel');
define('_AD_AVATAR', 'Avatar');
define('_AD_REGISTERED', 'Enregistré'); //Registered Date
// define('_AD_PRESSGEN','C\'est la première fois que vous entrez dans la section d\'administration. Appuyez sur le bouton ci-dessous pour continuer.');
define('_AD_LOGINADMIN', 'Connexion...');
define('_AD_WARNINGINSTALL', 'AVERTISSEMENT : Le répertoire %s existe sur votre serveur. <br> Pour des raisons de sécurité, vous devez supprimer ce répertoire.');
define('_AD_WARNINGWRITEABLE', 'AVERTISSEMENT : Le fichier %s est accessible en écriture sur votre serveur. <br>Pour des raisons de sécurité, vous devez changer les permissions de ce fichier.<br> Unix (444), Win32 (lecture seule)');
define('_AD_WARNINGNOTWRITEABLE', 'AVERTISSEMENT : Le dossier %s n\'est pas accessible en écriture par le serveur. <br> Veuillez changer les permissions de ce dossier. <br> Pour Unix (777), pour Win32 (décocher lecture seule)');
define('_AD_WARNINGXOOPSLIBINSIDE', 'AVERTISSEMENT : Le dossier %s est à la racine de votre site ! <br> Pour des raisons de sécurité, il est fortement recommandé de le déplacer à l\'extérieur de la racine de votre site.');
define('_AD_WARNING_OLD_PHP', 'AVERTISSEMENT : Envisagez de passer à une version plus récente de PHP. La version %s ou plus récente est recommandée et sera requise dans les futures versions XOOPS.');