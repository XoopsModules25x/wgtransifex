<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// Blocks
define('_MB_SYSTEM_ADMENU', 'Administration');
define('_MB_SYSTEM_RNOW', 'Inscrivez-vous!');
define('_MB_SYSTEM_LPASS', 'Mot de passe oublié ?');
define('_MB_SYSTEM_SEARCH', 'Recherche');
define('_MB_SYSTEM_ADVS', 'Recherche avancée');
define('_MB_SYSTEM_VACNT', 'Voir son compte');
define('_MB_SYSTEM_EACNT', 'Éditer son compte');
// RMV-NOTIFY
define('_MB_SYSTEM_NOTIF', 'Notifications');
define('_MB_SYSTEM_LOUT', 'Déconnexion');
define('_MB_SYSTEM_INBOX', 'Boîte de réception ');
define('_MB_SYSTEM_SUBMS', 'Envoyer un Article');
define('_MB_SYSTEM_WLNKS', 'Liens en attente');
define('_MB_SYSTEM_BLNK', 'Liens brisés');
define('_MB_SYSTEM_MLNKS', 'Liens modifiés');
define('_MB_SYSTEM_WDLS', 'Téléchargements en attente');
define('_MB_SYSTEM_BFLS', 'Fichiers brisés');
define('_MB_SYSTEM_MFLS', 'Téléchargements modifiés');
define('_MB_SYSTEM_TDMDOWNLOADS', 'Téléchargements en attente');
define('_MB_SYSTEM_EXTGALLERY', 'Photos en attente');
define('_MB_SYSTEM_SMARTSECTION', 'Articles');
define('_MB_SYSTEM_HOME', 'Accueil'); // link to home page in main menu block
define('_MB_SYSTEM_RECO', 'Nous recommander');
define('_MB_SYSTEM_PWWIDTH', 'Largeur de la fenêtre Pop-Up');
define('_MB_SYSTEM_PWHEIGHT', 'Hauteur de la fenêtre Pop-Up');
define('_MB_SYSTEM_LOGO', 'Fichier image du logo dans le répertoire <strong>%s</strong>');  // %s is your root image directory name
define('_MB_SYSTEM_COMPEND', 'Commentaires');
//define('_MB_SYSTEM_LOGGEDINAS',"Connecté comme");
define('_MB_SYSTEM_SADMIN', 'Montrer les groupes d\'administration ');
define('_MB_SYSTEM_SPMTO', 'Envoyer un message privé à %s');
define('_MB_SYSTEM_SEMTO', 'Envoyer un email à %s');
define('_MB_SYSTEM_DISPLAY', 'Afficher <strong>%s</strong> utilisateurs');
define('_MB_SYSTEM_DISPLAYA', 'Afficher les avatars des utilisateurs');
define('_MB_SYSTEM_NODISPGR', ' Ne pas afficher les utilisateurs dont le rang est:');
define('_MB_SYSTEM_DISPLAYC', 'Afficher %s commentaires');
define('_MB_SYSTEM_SECURE', 'Connexion sécurisée');
define('_MB_SYSTEM_NUMTHEME', '%s thèmes');
define('_MB_SYSTEM_THSHOW', 'Afficher une capture d\'image');
define('_MB_SYSTEM_THWIDTH', 'Largeur des captures d\'image');
define('_MB_SYSTEM_REMEMBERME', 'Se souvenir de moi');
//2.5.8
define('_MB_SYSTEM_BLOCK_HEIGHT', 'Hauteur du Bloc (lignes)');
