/**
 */

tinyMCE.addI18n('fr.xoopsmlcontent_dlg',{
    title : 'Ajouter du contenu multi-langage',
    subtitle : 'Sélectionnez une langue et mettez le contenu dans la boîte ci-dessous:',
    sellang : 'Choisir la langage',
    chooselang : 'Vous devez choisir une langue',
    maxstring : ' caractère(s) de %maxchar% entrés',
    alertmaxstring : 'Vous avez atteint le nombre maximum de caractères',
    delta_width : 100,
    delta_height : 100
});