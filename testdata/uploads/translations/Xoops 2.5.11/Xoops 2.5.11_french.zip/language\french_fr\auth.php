<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AUTH_MSG_AUTH_METHOD', 'utilisation de %s comme méthode d\'authentification');
define('_AUTH_LDAP_EXTENSION_NOT_LOAD', 'Extension PHP LDAP non chargée (vérifiez votre fichier de configuration PHP php.ini)');
define('_AUTH_LDAP_SERVER_NOT_FOUND', "Connexion au serveur impossible");
define('_AUTH_LDAP_USER_NOT_FOUND', 'Membre %s non trouvé dans l\'annuaire du serveur (%s) dans %s');
define('_AUTH_LDAP_CANT_READ_ENTRY', "Impossible de lire l'entrée %s");
define('_AUTH_LDAP_XOOPS_USER_NOTFOUND', 'Sorry, no corresponding user information has been found in the XOOPS database for connection: %s <br>' . 'Please verify your user data or set on the automatic provisioning');
define('_AUTH_LDAP_START_TLS_FAILED', 'Impossible d\'initialiser la connexion TLS');
