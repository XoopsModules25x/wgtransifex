tinyMCE.addI18n('fr.xoopsquote',{
quote_desc:"Insérer une citation"
});