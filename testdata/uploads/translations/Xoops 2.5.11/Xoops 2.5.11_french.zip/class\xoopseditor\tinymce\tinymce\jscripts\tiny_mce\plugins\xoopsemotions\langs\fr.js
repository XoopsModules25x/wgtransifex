/**
 */

tinyMCE.addI18n('fr.xoopsemotions',{
title : 'Insérer des émoticônes Xoops',
delta_width : '0',
delta_height : '0'
});