tinyMCE.addI18n('fr.example_dlg',{
title: "Ceci n'est qu'un exemple de titre"
});