<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_XO_ER_FILENOTFOUND','Le fichier demandé : <b>%s</b> n\'a pas été trouvé');
define('_XO_ER_CLASSNOTFOUND','La classe demandée %s n\'a pas été trouvée');
