<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MAIL_MSGBODY', 'Le corps du message est pas défini.');
define('_MAIL_FAILOPTPL', 'Impossible d\'ouvrir le fichier de modèle.');
define('_MAIL_FNAMENG', 'Le Nom de l\'expéditeur n\'est pas défini.');
define('_MAIL_FEMAILNG', 'Le courriel de l\'expéditeur n\'est pas défini.');
define('_MAIL_SENDMAILNG', 'Impossible d\'envoyer mail à %s.');
define('_MAIL_MAILGOOD', 'Courrier envoyé à %s.');
define('_MAIL_SENDPMNG', 'Impossible d\'envoyer un message privé à %s.');
define('_MAIL_PMGOOD', 'Message privé envoyé à %s.');
