<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PM_AM_PRUNE', 'Purge');
define('_PM_AM_PRUNEAFTER', 'Purger les messages postés après cette date (laisser vide pour ne pas avoir de date de début)');
define('_PM_AM_PRUNEBEFORE', 'Purger les messages postés avant cette date (laisser vide pour ne pas avoir de date de fin)');
define('_PM_AM_ONLYREADMESSAGES', 'Purger seulement les messages lus');
define('_PM_AM_INCLUDESAVE', "Inclure également les messages se trouvant dans les répertoires de sauvegarde des utilisateurs");
define('_PM_AM_NOTIFYUSERS', 'Notifier les utilisateurs concernés par cette purge ?');
define('_PM_AM_MESSAGESPRUNED', '%u message(s) purgé(s)');
define('_PM_AM_ERRORWHILEPRUNING', 'Une erreur s\'est produite pendant l\'opération de purge');
