<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MD_AM_VRSN', 'Version');
define('_MD_AM_FINDUSER', 'Rechercher des utilisateurs');
define('_MD_CPANEL_NEWS', 'Articles');
define('_MD_CPANEL_NEWS_DESC', 'Nouvelles concernant le développement de XOOPS');
define('_MD_CPANEL_PROJECT', 'Le Projet');
define('_MD_CPANEL_PROJECT_DESC', 'Site du projet XOOPS');
define('_MD_CPANEL_COMMUNITY', 'Communauté');
define('_MD_CPANEL_COMMUNITY_DESC', 'Site officiel de la communauté XOOPS');
define('_MD_CPANEL_LOCAL', 'Support local');
define('_MD_CPANEL_LOCAL_DESC', 'Supports locaux officiels XOOPS');
define('_MD_CPANEL_OVERVIEW', 'Aperçu du système');
define('_MD_CPANEL_PHPEXTENSIONS', 'Extensions PHP chargées');
define('_MD_CPANEL_VERSION', 'Version %s');
define('_MD_CPANEL_QUICKLINKS', 'Liens rapides');
define('_MD_CPANEL_SITE_ADMINISTRATION', 'Administration %s');
// for help page
define('_MD_CPANEL_HELPCENTER', 'Bienvenue au centre d\'assistance XOOPS');
