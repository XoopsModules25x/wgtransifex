<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_CAPTCHA_CAPTION', 'Code de confirmation');
define('_CAPTCHA_INVALID_CODE', 'Code de confirmation invalide !');
define('_CAPTCHA_TOOMANYATTEMPTS', 'Trop de tentatives !');
define('_CAPTCHA_MAXATTEMPTS', 'Le maximum d\'essais autorisés est : %d');
// For image mode
define('_CAPTCHA_RULE_IMAGE', 'Entrer des lettres à inclure dans l\'image');
define('_CAPTCHA_RULE_CASESENSITIVE', 'Le code est sensible à la casse');
define('_CAPTCHA_RULE_CASEINSENSITIVE', 'Le code est insensible à la casse');
define('_CAPTCHA_REFRESH', 'Cliquez pour rafraîchir l\'image si elle n\'est pas assez claire.');
// For text mode
define('_CAPTCHA_RULE_TEXT', 'Entrer le résultat à partir de l\'expression ');

/**
 * Error defines
 */
define('_CAPTCHA_LOADFILEERROR', 'Erreur : Impossible de charger le fichier %u dans le fichier %s à la ligne %s. ');
