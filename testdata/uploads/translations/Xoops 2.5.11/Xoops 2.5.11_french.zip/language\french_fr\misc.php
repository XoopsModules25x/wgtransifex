<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MSC_YOURNAMEC', 'Votre nom :');
define('_MSC_YOUREMAILC', 'Votre Courriel :');
define('_MSC_FRIENDNAMEC', 'Nom de votre ami :');
define('_MSC_FRIENDEMAILC', 'Courriel de votre ami :');
define('_MSC_RECOMMENDSITE', 'Recommander ce site à un ami');
// %s is your site name
define('_MSC_INTSITE', 'Site intéressant : %s');
define('_MSC_REFERENCESENT', 'La référence vers notre site a été envoyée à votre ami. Merci !');
define('_MSC_ENTERYNAME', 'Veuillez entrer votre nom');
define('_MSC_ENTERFNAME', 'Veuillez entrer le nom de votre ami');
define('_MSC_ENTERFMAIL', 'Veuillez entrer le courriel de votre ami');
define('_MSC_NEEDINFO', 'Vous devez remplir les informations demandées !');
define('_MSC_INVALIDEMAIL1', 'L\'adresse électronique que vous avez fourni n\'est pas une adresse valide.');
define('_MSC_INVALIDEMAIL2', 'Veuillez vérifier l\'adresse électronique et réessayer.');
define('_MSC_AVAVATARS', 'Avatars disponibles');
define('_MSC_SMILIES', 'Émoticônes');
define('_MSC_CLICKASMILIE', 'Cliquez sur une émoticône pour l\'insérer dans votre message.');
define('_MSC_CODE', 'Code');
define('_MSC_EMOTION', 'Émotion');

define('_MSC_CLICK_TO_OPEN_IMAGE', 'Cliquez pour voir l\'image originale dans une nouvelle fenêtre');
define('_MSC_RESIZED_IMAGE', 'Image redimensionnée');
define('_MSC_ORIGINAL_IMAGE', 'Image originale');
