<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PROFILE_AM_FIELD', 'Поле');
define('_PROFILE_AM_FIELDS', 'Поля');
define('_PROFILE_AM_CATEGORY', 'Категория');
define('_PROFILE_AM_STEP', 'Шаг');
define('_PROFILE_AM_SAVEDSUCCESS', '%s успешно сохранено');
define('_PROFILE_AM_DELETEDSUCCESS', '%s успешно удалено');
define('_PROFILE_AM_RUSUREDEL', 'Вы уверены, что хотите удалить %s');
define('_PROFILE_AM_FIELDNOTCONFIGURABLE', 'Поле не настраивается.');
define('_PROFILE_AM_ADD', 'Добавить %s');
define('_PROFILE_AM_EDIT', 'Редактировать %s');
define('_PROFILE_AM_TYPE', 'Тип поля');
define('_PROFILE_AM_VALUETYPE', 'Тип значения');
define('_PROFILE_AM_NAME', 'Имя');
define('_PROFILE_AM_TITLE', 'Заглавие');
define('_PROFILE_AM_DESCRIPTION', 'Описание');
define('_PROFILE_AM_REQUIRED', 'Необходимые?');
define('_PROFILE_AM_MAXLENGTH', 'Максимальная длина');
define('_PROFILE_AM_WEIGHT', 'Вес');
define('_PROFILE_AM_DEFAULT', 'По умолчанию');
define('_PROFILE_AM_NOTNULL', 'Не ноль?');
define('_PROFILE_AM_ARRAY', 'Массив');
define('_PROFILE_AM_EMAIL', 'Email');
define('_PROFILE_AM_INT', 'Целое число');
define('_PROFILE_AM_TXTAREA', 'Текстовая область ');
define('_PROFILE_AM_TXTBOX', 'Текстовое поле');
define('_PROFILE_AM_URL', 'URL');
define('_PROFILE_AM_OTHER', 'Другое');
define('_PROFILE_AM_FLOAT', 'Плавающая точка');
define('_PROFILE_AM_DECIMAL', 'Десятичное число');
define('_PROFILE_AM_UNICODE_ARRAY', 'Массив Unicode');
define('_PROFILE_AM_UNICODE_EMAIL', 'Unicode Email');
define('_PROFILE_AM_UNICODE_TXTAREA', 'Текстовая область Unicode');
define('_PROFILE_AM_UNICODE_TXTBOX', 'Текстовое поле Unicode');
define('_PROFILE_AM_UNICODE_URL', 'Unicode URL');
define('_PROFILE_AM_PROF_VISIBLE_ON', "Поле отображается в профиле этих групп");
define('_PROFILE_AM_PROF_VISIBLE_FOR', 'Поле отображается в профиле для этих групп');
define('_PROFILE_AM_PROF_VISIBLE', 'Видимость');
define('_PROFILE_AM_PROF_EDITABLE', 'Поле редактируется из профиля');
define('_PROFILE_AM_PROF_REGISTER', 'Показать в регистрационной форме');
define('_PROFILE_AM_PROF_SEARCH', 'Поиск по этим группам');
define('_PROFILE_AM_PROF_ACCESS', 'Профиль, доступный для этих групп');
define('_PROFILE_AM_PROF_ACCESS_DESC', '<ul>' . "<li>Admin groups: If a user belongs to admin groups, the current user has access if and only if one of the current user's groups is allowed to access admin group; else</li>" . "<li>Non basic groups: If a user belongs to one or more non basic groups (NOT admin, user, anonymous), the current user has access if and only if one of the current user's groups is allowed to allowed to any of the non basic groups; else</li>" . '<li>User group: If a user belongs to User group only, the current user has access if and only if one of his groups is allowed to access User group</li>' . '</ul>');
define('_PROFILE_AM_FIELDVISIBLE', 'Поле');
define('_PROFILE_AM_FIELDVISIBLEFOR', 'отображается для');
define('_PROFILE_AM_FIELDVISIBLEON', 'просмотр профиля');
define('_PROFILE_AM_FIELDVISIBLETOALL', '- Все');
define('_PROFILE_AM_FIELDNOTVISIBLE', 'не видно');
define('_PROFILE_AM_CHECKBOX', 'флажок');
define('_PROFILE_AM_GROUP', 'Выбор группы');
define('_PROFILE_AM_GROUPMULTI', 'Выбрать несколько групп');
define('_PROFILE_AM_LANGUAGE', 'Выбор языка');
define('_PROFILE_AM_RADIO', 'Радио-кнопки');
define('_PROFILE_AM_SELECT', 'Выбрать');
define('_PROFILE_AM_SELECTMULTI', 'Множественный выбор');
define('_PROFILE_AM_TEXTAREA', 'Текстовая область ');
define('_PROFILE_AM_DHTMLTEXTAREA', 'Текстовая область DHTML');
define('_PROFILE_AM_TEXTBOX', 'Текстовое поле');
define('_PROFILE_AM_TIMEZONE', 'Часовой пояс');
define('_PROFILE_AM_YESNO', 'Радио Да/Нет');
define('_PROFILE_AM_DATE', 'Дата');
define('_PROFILE_AM_AUTOTEXT', 'Авто текст');
define('_PROFILE_AM_DATETIME', 'Дата и время');
define('_PROFILE_AM_LONGDATE', 'Долгосрочная дата');
define('_PROFILE_AM_ADDOPTION', 'Добавить опцию');
define('_PROFILE_AM_REMOVEOPTIONS', 'Удалить параметры');
define('_PROFILE_AM_KEY', 'Значение, которое необходимо сохранить');
define('_PROFILE_AM_VALUE', 'Текст для отображения');
// User management
define('_PROFILE_AM_EDITUSER', 'Изменить пользователя');
define('_PROFILE_AM_SELECTUSER', 'Выберите пользователя');
define('_PROFILE_AM_ADDUSER', 'Добавить пользователя');
define('_PROFILE_AM_THEME', 'Темы');
define('_PROFILE_AM_RANK', 'Ранг');
define('_PROFILE_AM_USERDONEXIT', "Пользователь не существует!");
define('_PROFILE_MA_USERLEVEL', 'Уровень пользователя');
define('_PROFILE_MA_ACTIVE', 'Активный');
define('_PROFILE_MA_INACTIVE', 'Неактивный');
define('_PROFILE_AM_USERCREATED', 'Пользователь создал');
define('_PROFILE_AM_CANNOTDELETESELF', 'Удаление собственной учетной записи запрещено - используйте страницу своего профиля, чтобы удалить свою собственную учетную запись');
define('_PROFILE_AM_CANNOTDELETEADMIN', 'Удаление учетной записи администратора запрещено');
define('_PROFILE_AM_NOSELECTION', 'Ни один пользователь не выбран');
define('_PROFILE_AM_USER_ACTIVATED', 'Пользователь активирован');
define('_PROFILE_AM_USER_DEACTIVATED', 'Пользователь отключен');
define('_PROFILE_AM_USER_NOT_ACTIVATED', 'Ошибка: пользователь не активирован');
define('_PROFILE_AM_USER_NOT_DEACTIVATED', 'Ошибка: пользователь НЕ отключен.');
define('_PROFILE_AM_STEPNAME', 'Имя шага');
define('_PROFILE_AM_STEPORDER', 'Порядок шагов');
define('_PROFILE_AM_STEPSAVE', 'Сохранить после шага');
define('_PROFILE_AM_STEPINTRO', 'Описание шага');
//1.62
define('_PROFILE_AM_ACTION', 'Действие');
//1.63
define('_PROFILE_AM_REQUIRED_TOGGLE', 'Переключить обязательное поле');
define('_PROFILE_AM_REQUIRED_TOGGLE_SUCCESS', 'Успешно изменено обязательное поле');
define('_PROFILE_AM_REQUIRED_TOGGLE_FAILED', 'Смена обязательного поля');
define('_PROFILE_AM_SAVESTEP_TOGGLE', 'Переключатель сохранен');
define('_PROFILE_AM_SAVESTEP_TOGGLE_SUCCESS', 'Успешно изменено Сохранить после шага');
define('_PROFILE_AM_SAVESTEP_TOGGLE_FAILED', "Ошибка «Сохранить после шага»");
//XOOPS 2.5.9
define('_PROFILE_AM_CANNOTDEACTIVATEWEBMASTERS', 'Вы не можете деактивировать учетную запись для веб-мастера');

