<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license             GNU GPL 2 (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Main
define('_AM_SYSTEM_CONFIG', 'Конфигурация системы');
define('_AM_SYSTEM_CPANEL', 'Контрольная панель');
define('_AM_SYSTEM_UPDATE', 'Обновить');
define('_AM_SYSTEM_GOTOMODULE', 'Перейти к модулю');
define('_AM_SYSTEM_HELP', 'Помощь');
define('_AM_SYSTEM_HELP_VIEW', 'Показать справку');
define('_AM_SYSTEM_HELP_HIDE', 'Скрыть справку');
define('_AM_SYSTEM_TIPS', 'Советы');
define('_AM_SYSTEM_SECTION', 'Раздел');
define('_AM_SYSTEM_DESC', 'Описание');
define('_AM_SYSTEM_GO', 'Доступ к этому разделу');
define('_AM_SYSTEM_STATUS', 'Изменение статуса раздела');
define('_AM_SYSTEM_LOADING', 'Загрузка');
define('_AM_SYSTEM_ALL', 'Все');
define('_AM_SYSTEM_TIPS_MAIN', '<ul><li>Включение или отключение разделов системного модуля или просто получить доступ к модулю.</li></ul>');
define('_AM_SYSTEM_AVATAR_INFO', "<ul><li><span class='bold red'>%s</span> аватар.</li></ul>");
define('_AM_SYSTEM_BANNER_INFO', "<ul><li><span class='bold red'>%s</span> баннер.</li></ul>");
define('_AM_SYSTEM_COMMENT_INFO', "<ul><li><span class='bold red'>%s</span> комментарии.</li></ul>");
define('_AM_SYSTEM_GROUP_INFO', "<ul><li><span class='bold red'>%s</span> группа.</li></ul>");
define('_AM_SYSTEM_IMG_INFO', "<ul><li><span class='bold red'>%s</span> изображение.</li></ul>");
define('_AM_SYSTEM_SMILIES_INFO', "<ul><li><span class='bold red'>%s</span> смайл.</li></ul>");
define('_AM_SYSTEM_RANKS_INFO', "<ul><li><span class='bold red'>%s</span> ранг пользователей.</li></ul>");
define('_AM_SYSTEM_USERS_INFO', "<ul><li><span class='bold red'>%s</span> пользователи.</li></ul>");
// Admin Module Names and description
define('_AM_SYSTEM_ADGS', 'Группы');
define('_AM_SYSTEM_ADGS_DESC', 'Управление правами доступа модуля для пользователей и групп.');
define('_AM_SYSTEM_BANS', 'Баннеры');
define('_AM_SYSTEM_BANS_DESC', 'Управление XOOPS функцией рекламного баннера.');
define('_AM_SYSTEM_BLOCKS', 'Блоки');
define('_AM_SYSTEM_BLOCKS_DESC', 'Блоки могут отображать содержимое модуля на любой странице. Управление блоками.');
define('_AM_SYSTEM_MODULES', 'Модули');
define('_AM_SYSTEM_MODULES_DESC', 'Установить и деинсталлировать модули XOOPS.');
define('_AM_SYSTEM_SMLS', 'Смайлы');
define('_AM_SYSTEM_SMLS_DESC', 'Скрыть, изменить и добавить пользовательские смайлики для использования в сообщениях и комментариях.');
define('_AM_SYSTEM_RANK', 'Ранги пользователей');
define('_AM_SYSTEM_RANK_DESC', 'Редактировать и создавать названные ранги для пользователей и модераторов.');
define('_AM_SYSTEM_USER', 'Пользователи');
define('_AM_SYSTEM_USER_DESC', 'Вручную добавлять пользователей, профили пользователей и изменения паролей.');
define('_AM_SYSTEM_PREF', 'Настройки');
define('_AM_SYSTEM_PREF_DESC', 'Изменение глобальных настроек для вашего сайта XOOPS.');
define('_AM_SYSTEM_MLUS', 'Email пользователя');
define('_AM_SYSTEM_MLUS_DESC', 'Отправить электронную почту или личные сообщения одному или нескольким пользователям.');
define('_AM_SYSTEM_IMAGES', 'Управление изображениями');
define('_AM_SYSTEM_IMAGES_DESC', 'Создание категорий для менеджера изображений и загружать изображения.');
define('_AM_SYSTEM_AVATARS', 'Аватары');
define('_AM_SYSTEM_AVATARS_DESC', 'Вы можете добавить аватары для пользователей, для их профилей.');
define('_AM_SYSTEM_TPLSETS', 'Шаблон');
define('_AM_SYSTEM_TPLSETS_DESC', 'Модуль редактирования шаблонов, без редактирования файлов на диске.');
define('_AM_SYSTEM_COMMENTS', 'Комментарии');
define('_AM_SYSTEM_COMMENTS_DESC', 'Многие модули позволяют пользователям возможность отправлять комментарии. Вы можете удалить или отредактировать их здесь.');
define('_AM_SYSTEM_FILEMANAGER', 'Файловый менеджер');
define('_AM_SYSTEM_FILEMANAGER_DESC', 'XOOPS файловый менеджер.');
define('_AM_SYSTEM_MAINTENANCE', 'Обслуживание');
define('_AM_SYSTEM_MAINTENANCE_DESC', 'Инструменты технического обслуживания для таблиц базы данных, папок кэша и таблицы сеансов.');
// Messages
define('_AM_SYSTEM_DBUPDATED', '​​База данных обновлена!');
define('_AM_SYSTEM_DBERROR', 'База данных не была обновлена ​​из-за какой-то ошибки!');
define('_AM_SYSTEM_NOTACTIVE', 'Этот раздел не активен!');
// Group permission phrases
define('_MD_AM_PERMADDNG', 'Невозможно добавить разрешение %s в %s для группы %s');
define('_MD_AM_PERMADDOK', 'Добавлено разрешение %s в %s для группы %s');
define('_MD_AM_PERMRESETNG', 'Не удалось установить разрешения группы для модуля %s');
define('_MD_AM_PERMADDNGP', 'Все родительские элементы должны быть выбраны.');
define('_AM_SYSTEM_UNINSTALL', 'Удалить');

//2.5.7
define('_AM_SYSTEM_USAGE', 'Применить');
define('_AM_SYSTEM_ACTIVE', 'Активный');
