/**
 */

tinyMCE.addI18n('ru.xoopsemotions',{
desc : 'Вставить смайлики Xoops',
delta_width : '0',
delta_height : '0'
});