<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_BLOCKS_ADMIN', 'Управление блоками');
define('_AM_SYSTEM_BLOCKS_MANAGMENT', 'Управление');
define('_AM_SYSTEM_BLOCKS_ADDBLOCK', 'Добавить новый блок');
define('_AM_SYSTEM_BLOCKS_EDITBLOCK', 'Редактирование блока');
define('_AM_SYSTEM_BLOCKS_CLONEBLOCK', 'Клонирование блока');
// Forms
define('_AM_SYSTEM_BLOCKS_CUSTOM', 'Пользовательский блок');
define('_AM_SYSTEM_BLOCKS_TYPES', 'Все типы');
define('_AM_SYSTEM_BLOCKS_GENERATOR', 'Модули');
define('_AM_SYSTEM_BLOCKS_GROUP', 'Группы');
define('_AM_SYSTEM_BLOCKS_SVISIBLEIN', 'Страница');
define('_AM_SYSTEM_BLOCKS_DISPLAY', 'Показать блок ');
define('_AM_SYSTEM_BLOCKS_HIDE', 'Скрыть блок ');
define('_AM_SYSTEM_BLOCKS_CLONE', 'Клон');
define('_AM_SYSTEM_BLOCKS_SIDELEFT', 'Влево');
define('_AM_SYSTEM_BLOCKS_SIDETOPLEFT', 'Верхняя левая');
define('_AM_SYSTEM_BLOCKS_SIDETOPCENTER', 'Верхняя по центру');
define('_AM_SYSTEM_BLOCKS_SIDETOPRIGHT', 'Верхняя правая');
define('_AM_SYSTEM_BLOCKS_SIDERIGHT', 'Вправо');
define('_AM_SYSTEM_BLOCKS_SIDEBOTTOMLEFT', 'Нижняя левая');
define('_AM_SYSTEM_BLOCKS_SIDEBOTTOMCENTER', 'Нижняя по центру');
define('_AM_SYSTEM_BLOCKS_SIDEBOTTOMRIGHT', 'Нижняя правая');

define('_AM_SYSTEM_BLOCKS_SIDEFOOTERLEFT', 'Нижний колонтитул левый');
define('_AM_SYSTEM_BLOCKS_SIDEFOOTERCENTER', 'Нижний колонтитул по центру');
define('_AM_SYSTEM_BLOCKS_SIDEFOOTERRIGHT', 'Нижний колонтитул правый');

define('_AM_SYSTEM_BLOCKS_ADD', 'Добавить блок');
define('_AM_SYSTEM_BLOCKS_MANAGE', 'Управление блоком');
define('_AM_SYSTEM_BLOCKS_NAME', 'Имя');
define('_AM_SYSTEM_BLOCKS_TYPE', 'Тип блока');
define('_AM_SYSTEM_BLOCKS_SBLEFT', 'Боковой блок - левый');
define('_AM_SYSTEM_BLOCKS_SBRIGHT', 'Боковой блок - справа');
define('_AM_SYSTEM_BLOCKS_CBLEFT', 'Центральный блок - левый');
define('_AM_SYSTEM_BLOCKS_CBRIGHT', 'Центральный блок - правый');
define('_AM_SYSTEM_BLOCKS_CBCENTER', 'Центральный блок - по центру');
define('_AM_SYSTEM_BLOCKS_CBBOTTOMLEFT', 'Центральный блок - в левом нижнем углу');
define('_AM_SYSTEM_BLOCKS_CBBOTTOMRIGHT', 'Центральный блок - в правом нижнем углу');

define('_AM_SYSTEM_BLOCKS_CBFOOTERLEFT', 'Нижний колонтитул - левый');
define('_AM_SYSTEM_BLOCKS_CBFOOTERCENTER', 'Нижний колонтитул - по центру');
define('_AM_SYSTEM_BLOCKS_CBFOOTERRIGHT', 'Нижний колонтитул - правый');

define('_AM_SYSTEM_BLOCKS_CBBOTTOM', 'Центральный блок - нижний');
define('_AM_SYSTEM_BLOCKS_WEIGHT', 'Вес');
define('_AM_SYSTEM_BLOCKS_VISIBLE', 'Видимый');
define('_AM_SYSTEM_BLOCKS_VISIBLEIN', 'Видимый в');
define('_AM_SYSTEM_BLOCKS_TOPPAGE', 'Главная страница');
define('_AM_SYSTEM_BLOCKS_ALLPAGES', 'Все страницы');
define('_AM_SYSTEM_BLOCKS_UNASSIGNED', 'Неназначенный');
define('_AM_SYSTEM_BLOCKS_TITLE', 'Заглавие');
define('_AM_SYSTEM_BLOCKS_CONTENT', 'Содержание');
define('_AM_SYSTEM_BLOCKS_USEFULTAGS', 'Полезные теги:');
define('_AM_SYSTEM_BLOCKS_BLOCKTAG', '%s напечатает %s');
define('_AM_SYSTEM_BLOCKS_CTYPE', 'Тип содержимого');
define('_AM_SYSTEM_BLOCKS_HTML', 'HTML');
define('_AM_SYSTEM_BLOCKS_PHP', 'PHP Script');
define('_AM_SYSTEM_BLOCKS_AFWSMILE', 'Auto Format (смайлики включены)');
define('_AM_SYSTEM_BLOCKS_AFNOSMILE', 'Auto Format (смайлики выключены)');
define('_AM_SYSTEM_BLOCKS_BCACHETIME', 'Срок хранения кэша');
define('_AM_SYSTEM_BLOCKS_CUSTOMHTML', 'Пользовательский блок (HTML)');
define('_AM_SYSTEM_BLOCKS_CUSTOMPHP', 'Пользовательский блок (PHP)');
define('_AM_SYSTEM_BLOCKS_CUSTOMSMILE', 'Пользовательский блок (Auto Format + smilies)');
define('_AM_SYSTEM_BLOCKS_CUSTOMNOSMILE', 'Пользовательский блок (Auto Format)');
define('_AM_SYSTEM_BLOCKS_EDITTPL', 'Изменить шаблон');
define('_AM_SYSTEM_BLOCKS_OPTIONS', 'Опции');
define('_AM_SYSTEM_BLOCKS_DRAG', 'Перетащите блок');
// Messages
define('_AM_SYSTEM_BLOCKS_DBUPDATED', _AM_SYSTEM_DBUPDATED);
define('_AM_SYSTEM_BLOCKS_RUSUREDEL', 'Вы действительно хотите удалить этот блок? <div class="bold">%s</div>');
define('_AM_SYSTEM_BLOCKS_SYSTEMCANT', 'Системные блоки не могут быть удалены!');
define('_AM_SYSTEM_BLOCKS_MODULECANT', 'Этот блок не может быть удален напрямую! Если вы хотите отключить этот блок, отключите модуль.');
// Tips
define('_AM_SYSTEM_BLOCKS_TIPS', '<ul>
<li>You can easily change side or order position with the drag\'n drop, click on <img class="tooltip" src="%s" alt="' . _AM_SYSTEM_BLOCKS_DRAG . '" title="' . _AM_SYSTEM_BLOCKS_DRAG . '" /> this image and set your site just the way you want it</li>
<li>Add a new custom block</li>
<li>Set block online or offline by clicking on <img class="tooltip" width="16" src="%s" alt="' . _AM_SYSTEM_BLOCKS_DISPLAY . '" title="' . _AM_SYSTEM_BLOCKS_DISPLAY . '"/> or <img class="tooltip" width="16" src="%s" alt="' . _AM_SYSTEM_BLOCKS_HIDE . '" title="' . _AM_SYSTEM_BLOCKS_HIDE . '" /></li>
</ul>');

define('_AM_SYSTEM_BLOCKS_FOOTER_LEFT', 'Нижний колонтитул левый');
define('_AM_SYSTEM_BLOCKS_FOOTER_CENTER', 'Нижний колонтитул по центру');
define('_AM_SYSTEM_BLOCKS_FOOTER_RIGHT', 'Нижний колонтитул правый');
