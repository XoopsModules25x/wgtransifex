<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// Blocks
define('_MB_SYSTEM_ADMENU', 'Меню администратора');
define('_MB_SYSTEM_RNOW', 'Зарегистрируйтесь сейчас!');
define('_MB_SYSTEM_LPASS', 'Забыли пароль?');
define('_MB_SYSTEM_SEARCH', 'Поиск');
define('_MB_SYSTEM_ADVS', 'Расширенный поиск');
define('_MB_SYSTEM_VACNT', 'Посмотреть аккаунт');
define('_MB_SYSTEM_EACNT', 'Редактировать аккаунт');
// RMV-NOTIFY
define('_MB_SYSTEM_NOTIF', 'Уведомления');
define('_MB_SYSTEM_LOUT', 'Выйти');
define('_MB_SYSTEM_INBOX', 'Входящие');
define('_MB_SYSTEM_SUBMS', 'Ожидающие новости');
define('_MB_SYSTEM_WLNKS', 'Ожидающие ссылки');
define('_MB_SYSTEM_BLNK', 'Неработающие ссылки');
define('_MB_SYSTEM_MLNKS', 'Модифицировать ссылки');
define('_MB_SYSTEM_WDLS', 'Ожидающие загрузки');
define('_MB_SYSTEM_BFLS', 'Битые файлы');
define('_MB_SYSTEM_MFLS', 'Модифицировать загрузки');
define('_MB_SYSTEM_TDMDOWNLOADS', 'Ожидающие загрузки');
define('_MB_SYSTEM_EXTGALLERY', 'Ожидающие фото');
define('_MB_SYSTEM_SMARTSECTION', 'Cтатьи');
define('_MB_SYSTEM_HOME', 'Главная'); // link to home page in main menu block
define('_MB_SYSTEM_RECO', 'Рекомендовать нас');
define('_MB_SYSTEM_PWWIDTH', 'Ширина всплывающего окна');
define('_MB_SYSTEM_PWHEIGHT', 'Высота всплывающего окна');
define('_MB_SYSTEM_LOGO', 'Файл логотипа из директории %s ');  // %s is your root image directory name
define('_MB_SYSTEM_COMPEND', 'Комментарии');
//define('_MB_SYSTEM_LOGGEDINAS',"Вы вошли как");
define('_MB_SYSTEM_SADMIN', 'Показать администратора группы');
define('_MB_SYSTEM_SPMTO', 'Отправить личное сообщение для %s');
define('_MB_SYSTEM_SEMTO', 'Отправить Email для %s');
define('_MB_SYSTEM_DISPLAY', 'Показывать %s участников');
define('_MB_SYSTEM_DISPLAYA', 'Показать аватары участников');
define('_MB_SYSTEM_NODISPGR', 'Не показывать пользователей ранг которых:');
define('_MB_SYSTEM_DISPLAYC', 'Показывать %s комментариев');
define('_MB_SYSTEM_SECURE', 'Безопасный логин');
define('_MB_SYSTEM_NUMTHEME', '%s темы');
define('_MB_SYSTEM_THSHOW', 'Показать скриншот изображения');
define('_MB_SYSTEM_THWIDTH', 'Ширина рисунка внешнего вида');
define('_MB_SYSTEM_REMEMBERME', 'Запомнить меня');
//2.5.8
define('_MB_SYSTEM_BLOCK_HEIGHT', 'Высота блока (линии)');
