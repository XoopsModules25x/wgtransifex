<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
//%%%%%%    File Name readpmsg.php     %%%%%
define('_PM_DELETED', 'Ваше сообщение(я) удалены');
define('_PM_PRIVATEMESSAGE', 'Персональные сообщения');
define('_PM_INBOX', 'Входящие');
define('_PM_FROM', 'Из');
define('_PM_YOUDONTHAVE', "У Вас нет личных сообщений");
define('_PM_FROMC', 'От:');
define('_PM_SENTC', 'Отправлено:'); // The date of message sent
define('_PM_PROFILE', 'Профиль');
// %s is a username
define('_PM_PREVIOUS', 'Предыдущее сообщение');
define('_PM_NEXT', 'Следующее сообщение');
//%%%%%%    File Name pmlite.php     %%%%%
define('_PM_SORRY', 'Сожалеем! Вы не являетесь зарегистрированным пользователем.');
define('_PM_REGISTERNOW', 'Зарегистрируйтесь сейчас!');
define('_PM_GOBACK', 'Вернуться');
define('_PM_USERNOEXIST', "Выбранный пользователь не существует в базе данных.");
define('_PM_PLZTRYAGAIN', 'Пожалуйста, проверьте имя и попробуйте снова.');
define('_PM_MESSAGEPOSTED', 'Ваше сообщение опубликовано');
define('_PM_CLICKHERE', 'Вы можете щелкнуть здесь, чтобы просмотреть персональные сообщения');
define('_PM_ORCLOSEWINDOW', 'Или нажмите здесь, чтобы закрыть это окно.');
define('_PM_USERWROTE', '%s писал:');
define('_PM_TO', 'To: ');
define('_PM_SUBJECTC', 'Предмет:');
define('_PM_MESSAGEC', 'Сообщение: ');
define('_PM_CLEAR', 'Очистить');
define('_PM_CANCELSEND', 'Отменить отправление');
define('_PM_SUBMIT', 'Отправить');
define('_PM_SAVEINOUTBOX', 'Сохранить копию в исходной папке?');
//%%%%%%    File Name viewpmsg.php     %%%%%
define('_PM_SUBJECT', ' Тема');
define('_PM_DATE', 'Дата');
define('_PM_NOTREAD', 'Не прочтено');
define('_PM_SEND', 'Отправить новое сообщение');
define('_PM_DELETE', 'Удалить');
define('_PM_TOSAVE', 'Переместить в Savebox');
define('_PM_UNSAVE', 'Выйти из Savebox');
define('_PM_EMPTY', 'Пусто');
define('_PM_REPLY', 'Ответ');
define('_PM_PLZREG', 'Пожалуйста, зарегистрируйтесь, чтобы отправлять персональные сообщения!');
define('_PM_SAVED_PART', 'Вам разрешается %d в Savebox и сохранено %d сообщений за это время');
define('_PM_SAVED_ALL', 'Сообщения были перемещены в папку Savebox');
define('_PM_UNSAVED', 'Сообщения удалены из Savebox');
define('_PM_EMPTIED', 'Папка пуста');
define('_PM_RUSUREEMPTY', 'Вы уверены, очистить ящик?');
define('_PM_SURE_TO_DELETE', 'Вы действительно хотите удалить эти сообщение(я)?');
define('_PM_ONLINE', 'В сети');
define('_PM_OUTBOX', 'Исходящие');
define('_PM_SAVEBOX', 'Savebox');
define('_PM_SAVE', 'СОХРАНИТЬ');
//WANISYS.NET PM HACK1.5
define('_PM_SORT', 'СОРТИРОВАТЬ');
define('_PM_ORDER', 'ЗАКАЗ');
define('_PM_TIME', 'Дата публикации');
define('_PM_ASC', 'ASC');
define('_PM_DESC', 'DESC');
define('_PM_LIMIT', 'ПМ на страницу');
define('_PM_BACKTOBOX', 'Вернуться в ящик');
define('_PM_SORTSUBMIT', 'Отправить');
define('_PM_PREVIOUSP', 'Предыдущий');
define('_PM_NEXTP', 'Следующий');
define('_PM_MAILNOTIFY', "%s-Вы получили новое ПМ от %s");
define('_PM_MAILMESSAGE', "Здравствуйте!\nНовое ПМ получено из %s\n\nНазвание ПM\n%s\n\nВы можете посмотреть ПМ здесь\n%s\n\n-----------\nВы получили это сообщение, потому что Вы выбрали уведомление, когда будете получать новый ПM\n\nВы можете изменить ПM-Настройка\n%s\n\nПожалуйста, не отвечайте на это сообщение\n\n---------\nС наилучшими пожеланиями\n%s\n%s\n%s");
define('_PM_EMAIL', 'Отправить по электронной почте');
define('_PM_EMAIL_DESC', 'Dear %s, this is a message transfered from your account at ' . $GLOBALS['xoopsConfig']['sitename']);
define('_PM_EMAIL_FROM', 'От %s');
define('_PM_EMAIL_TO', 'To %s');
define('_PM_EMAIL_SUBJECT', '[message]%s');
define('_PM_EMAIL_MESSAGE', 'Содержание сообщения');
define('_PM_ACTION_DONE', 'Операция выполнена успешно');
define('_PM_ACTION_ERROR', 'Операция не удалась');
//XOOPS 2.5.2
define('_PM_READ', 'Уже прочитано');
define('_PM_SUBJECT_ICONS', 'Иконки темы:');
