<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_XO_ER_FILENOTFOUND','Запрошенный файл: <b>%s</b> не найден');
define('_XO_ER_CLASSNOTFOUND','Запрашиваемый класс %s не найден');
