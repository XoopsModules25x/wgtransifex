<?php

define('_AM_XMF_MODULE_NOTFOUND','Пожалуйста, установите или повторно активировать модуль %1$s модуль. Минимальная версия, требуемая: %2$s');
define('_AM_XMF_MODULE_VERSION','Минимальный %1$s модуль версии требуется: %2$s (Ваша версия %3$s)');
define('_AM_XMF_MODULE_INSTALLED', 'Модуль \'%s\' установлен!');
define('_AM_XMF_MODULE_NOT_INSTALLED', 'Модуль \'%s\' не установлен!');

define('_DB_XMF_TABLE_IS_NOT_DEFINED','Таблица не определена');
