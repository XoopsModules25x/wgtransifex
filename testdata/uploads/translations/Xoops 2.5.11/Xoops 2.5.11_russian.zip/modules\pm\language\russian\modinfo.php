<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PM_MI_NAME', 'Персональное сообщение');
define('_PM_MI_DESC', 'Модуль для обмена персональными сообщениями между пользователями');
define('_PM_MI_INDEX', 'Главная');
define('_PM_MI_PRUNE', 'Черновики');
define('_PM_MI_LINK_TITLE', 'PM Link');
define('_PM_MI_LINK_DESCRIPTION', 'Показывает ссылку для отправки личного сообщения пользователю');
define('_PM_MI_MESSAGE', 'Написать сообщение');
define('_PM_MI_PRUNESUBJECT', 'Строка темы сюжетной линии');
define('_PM_MI_PRUNESUBJECT_DESC', 'Это будет предметом ПM для пользователя, полученным после очистки');
define('_PM_MI_PRUNEMESSAGE', 'Очистка тела сообщения');
define('_PM_MI_PRUNEMESSAGE_DESC', "Это сообщение будет в теле сообщения пользователя после того, как одно или несколько из их будут удалены из  почтового ящика во время очистки ПM. Использовано {PM_COUNT} в тексте, который должен быть заменен количеством сообщений, удаленных из папки входящих сообщений этого пользователя");
define('_PM_MI_PRUNESUBJECTDEFAULT', 'Сообщения, удаленные во время очистки');
define('_PM_MI_PRUNEMESSAGEDEFAULT', 'Во время очистки личных сообщений XOOPS удалил {PM_COUNT} сообщения из вашего почтового ящика, чтобы сэкономить место и ресурсы');
define('_PM_MI_MAXSAVE', 'Максимальное количество элементов в savebox');
define('_PM_MI_MAXSAVE_DESC', ');
define('_PM_MI_PERPAGE', 'Сообщений на странице');
define('_PM_MI_PERPAGE_DESC', ');
//1.07
define('_PM_MI_ABOUT', 'О модуле');
