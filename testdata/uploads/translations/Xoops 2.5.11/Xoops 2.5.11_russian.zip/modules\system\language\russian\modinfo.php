<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// Module Info
// The name of this module
define('_MI_SYSTEM_NAME', 'Система');
// A brief description of this module
define('_MI_SYSTEM_DESC', 'Управление основными настройками.');
// Names of blocks for this module (Not all module has blocks)
define('_MI_SYSTEM_BNAME2', 'Меню пользователя');
define('_MI_SYSTEM_BNAME3', 'Логин');
define('_MI_SYSTEM_BNAME4', 'Поиск');
define('_MI_SYSTEM_BNAME5', 'Ожидает проверки');
define('_MI_SYSTEM_BNAME6', 'Главное меню');
define('_MI_SYSTEM_BNAME7', 'Информация о сайте');
define('_MI_SYSTEM_BNAME8', 'Кто Online');
define('_MI_SYSTEM_BNAME9', 'Лучшие авторы');
define('_MI_SYSTEM_BNAME10', 'Новые участники');
define('_MI_SYSTEM_BNAME11', 'Недавние комментарии');
// RMV-NOTIFY
define('_MI_SYSTEM_BNAME12', 'Варианты уведомлений');
define('_MI_SYSTEM_BNAME13', 'Темы');
// Names of admin menu items
define('_MI_SYSTEM_ADMENU1', 'Баннеры');
define('_MI_SYSTEM_ADMENU2', 'Блоки');
define('_MI_SYSTEM_ADMENU3', 'Группы');
define('_MI_SYSTEM_ADMENU5', 'Модули');
define('_MI_SYSTEM_ADMENU6', 'Настройки');
define('_MI_SYSTEM_ADMENU7', 'Смайлы');
define('_MI_SYSTEM_ADMENU9', 'Ранги пользователей');
define('_MI_SYSTEM_ADMENU10', 'Изменить пользователя');
define('_MI_SYSTEM_ADMENU11', 'Email пользователя');
define('_MI_SYSTEM_ADMENU12', 'Найти пользователей');
define('_MI_SYSTEM_ADMENU13', 'Изображения');
define('_MI_SYSTEM_ADMENU14', 'Аватары');
define('_MI_SYSTEM_ADMENU15', 'Шаблон');
define('_MI_SYSTEM_ADMENU16', 'Комментарии');
//Preference
define('_MI_SYSTEM_PREFERENCE_BREAK_GENERAL', 'Основные настройки');
define('_MI_SYSTEM_PREFERENCE_TIPS', 'Помощь онлайн?');
define('_MI_SYSTEM_PREFERENCE_TIPS_DSC', 'Дает вам советы и помощь онлайн');
define('_MI_SYSTEM_PREFERENCE_ICONS', 'Иконки');
define('_MI_SYSTEM_PREFERENCE_BREADCRUMB', 'Навигация "Хлебные крошки"');
define('_MI_SYSTEM_PREFERENCE_BREAK_ACTIVE', 'Активный раздел');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_AVATARS', 'Активные аватары');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_BANNERS', 'Активные баннеры');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_BLOCKSADMIN', ');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_COMMENTS', 'Активные комментарии');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_FILEMANAGER', 'Активный файловый менеджер');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_GROUPS', ');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_IMAGES', 'Активные менеджер изображения');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_MAILUSERS', 'Активные Email пользователи');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_MODULESADMIN', ');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_PREFERENCES', ');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_SMILIES', 'Активные смайлы');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_TPLSETS', ');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_USERRANK', 'Активные ранги пользователей');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_USERS', 'Активные пользователи');
define('_MI_SYSTEM_PREFERENCE_ACTIVE_MAINTENANCE', 'Активное техническое обслуживание');
define('_MI_SYSTEM_PREFERENCE_BREAK_PAGER', 'Количество строк для отображения в администрации');
define('_MI_SYSTEM_PREFERENCE_AVATARS_PAGER', 'Количество аватаров, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_BANNERS_PAGER', 'Количество баннеров, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_COMMENTS_PAGER', 'Количество комментариев, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_GROUPS_PAGER', 'Количество групп, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_IMAGES_PAGER', 'Количество изображений, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_SMILIES_PAGER', 'Количество смайликов, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_USERRANKS_PAGER', 'Количество рангов, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_USERS_PAGER', 'Количество пользователей, отображаемых на одной странице');
define('_MI_SYSTEM_PREFERENCE_BREAK_EDITOR', 'Настройки редактора');
define('_MI_SYSTEM_PREFERENCE_BLOCKS_EDITOR', 'Редактор блоков:');
define('_MI_SYSTEM_PREFERENCE_BLOCKS_EDITOR_DSC', ');
define('_MI_SYSTEM_PREFERENCE_COMMENTS_EDITOR', 'Редактор для комментариев:');
define('_MI_SYSTEM_PREFERENCE_COMMENTS_EDITOR_DSC', ');
define('_MI_SYSTEM_PREFERENCE_GENERAL_EDITOR', 'Редактор для всех модулей:');
define('_MI_SYSTEM_PREFERENCE_GENERAL_EDITOR_DSC', ');
define('_MI_SYSTEM_PREFERENCE_ANONPOST', ');
define('_MI_SYSTEM_PREFERENCE_REDIRECT', ');
define('_MI_SYSTEM_PREFERENCE_JQUERY_THEME', 'Тема jQuery');
