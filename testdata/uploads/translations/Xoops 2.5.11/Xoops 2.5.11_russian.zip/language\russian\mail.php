<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MAIL_MSGBODY', 'Сообщение не написано.');
define('_MAIL_FAILOPTPL', 'Ошибка при открытии файла шаблона.');
define('_MAIL_FNAMENG', 'От кого не указано.');
define('_MAIL_FEMAILNG', 'Не указан Email.');
define('_MAIL_SENDMAILNG', 'Не удалось отправить почту %s.');
define('_MAIL_MAILGOOD', 'Почта отправленная %s.');
define('_MAIL_SENDPMNG', 'Не удалось отправить личное сообщение для %s.');
define('_MAIL_PMGOOD', 'Личное сообщение отправлено %s.');
