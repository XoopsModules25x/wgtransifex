<?php
//
// _LANGCODE: ru
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

// RSS feed URLs
return array('http://www.xoops.org/backend.php');