/**
 */

tinyMCE.addI18n('ru.xoopsmlcontent',{
desc : 'Вставка многоязычного контента',
delta_width : '0',
delta_height : '0'
});