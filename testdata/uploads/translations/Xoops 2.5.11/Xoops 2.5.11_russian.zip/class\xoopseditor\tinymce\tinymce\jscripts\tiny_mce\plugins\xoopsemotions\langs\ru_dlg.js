/**
 */

tinyMCE.addI18n('ru.xoopsemotions_dlg',{
title : 'Вставить Xoops смайлики',
tab_emotionsbrowser: 'Смайлики',
tab_emotionsadmin: 'Добавить смайлики',
error_noemotions: 'Нет смайликов в базе данных !!!'
});