tinyMCE.addI18n('ru.xoopsquote',{
quote_desc:"Вставить цитату"
});