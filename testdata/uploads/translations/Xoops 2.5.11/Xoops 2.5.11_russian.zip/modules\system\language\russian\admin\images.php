<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_IMAGES_MANAGER', 'Управление изображениями');
define('_AM_SYSTEM_IMAGES_MAIN', 'Главный');
define('_AM_SYSTEM_IMAGES_IMGLIST', 'Список изображений');
// Main
define('_AM_SYSTEM_IMAGES_ADDCAT', 'Добавить категорию');
define('_AM_SYSTEM_IMAGES_ADDIMG', 'Добавить изображение');
define('_AM_SYSTEM_IMAGES_MULTIUPLOAD', 'Множественная загрузка');
define('_AM_SYSTEM_IMAGES_EDITIMG', 'Редактирование изображения');
define('_AM_SYSTEM_IMAGES_CATLIST', 'Список категорий');
define('_AM_SYSTEM_IMAGES_NOCAT', 'Нет доступных категорий');
define('_AM_SYSTEM_IMAGES_NAME', 'Имя');
define('_AM_SYSTEM_IMAGES_NBIMAGES', 'Изображения');
define('_AM_SYSTEM_IMAGES_MAXSIZE', 'Максимальный размер');
define('_AM_SYSTEM_IMAGES_MAXWIDTH', 'Максимальная ширина');
define('_AM_SYSTEM_IMAGES_MAXHEIGHT', 'Максимальная высота');
define('_AM_SYSTEM_IMAGES_DISPLAY', 'Показать');
define('_AM_SYSTEM_IMAGES_ACTIONS', 'Действия');
define('_AM_SYSTEM_IMAGES_VIEW', 'Посмотреть');
define('_AM_SYSTEM_IMAGES_INDB', ' Хранить в базе данных (в виде двоичных данных "Blob")');
define('_AM_SYSTEM_IMAGES_ASFILE', ' Хранить в виде файлов (в каталоге дата загрузки)<br />');
define('_AM_SYSTEM_IMAGES_IMGCATNAME', 'Название категории:');
define('_AM_SYSTEM_IMAGES_IMGCATRGRP', 'Выберите группы для использования менеджера изображений:<br /><br /><span style="font-weight: normal;">Этой группе разрешено использовать менеджер изображений для выбора изображений, но не загрузки. Веб-мастер имеет автоматический доступ.</span>');
define('_AM_SYSTEM_IMAGES_IMGCATWGRP', 'Выберите группы которым разрешено загружать изображения:<br /><br /><span style="font-weight: normal;">Типичное использование для модератора и администратора группы.</span>');
define('_AM_SYSTEM_IMAGES_IMGCATDISPLAY', 'Показать эту категорию?');
define('_AM_SYSTEM_IMAGES_IMGCATSTRTYPE', 'Изображения загружаются:');
define('_AM_SYSTEM_IMAGES_STRTYOPENG', 'Это не может быть изменено впоследствии!');
define('_AM_SYSTEM_IMAGES_IMGCATWEIGHT', 'Порядок отображения в менеджере изображений:');
define('_AM_SYSTEM_IMAGES_OFF', 'Показывать в менеджере изображений');
define('_AM_SYSTEM_IMAGES_ON', 'Не отображается в менеджере изображений');
define('_AM_SYSTEM_IMAGES_URL', 'Показать изображение URL');
// Messages
define('_AM_SYSTEM_IMAGES_RUDELIMG', 'Вы уверены, что хотите удалить этот файл?');
define('_AM_SYSTEM_IMAGES_FAILSAVE', 'Не удалось сохранить изображение %s  в базу данных');
define('_AM_SYSTEM_IMAGES_RUDELIMGCAT', 'Вы уверены, что хотите удалить эту категорию и все его файлы изображений?');
define('_AM_SYSTEM_IMAGES_FAILDEL', 'Ошибка удаления изображения %s из базы данных');
define('_AM_SYSTEM_IMAGES_FAILDELCAT', 'Ошибка удаления категории изображения %s из базы данных');
define('_AM_SYSTEM_IMAGES_FAILUNLINK', 'Ошибка удаления изображения %s из каталога сервера');
// Tips
define('_AM_SYSTEM_IMAGES_TIPS', '<ul><li>Управление категориями изображений и разрешениями пользователей</li></ul>');
