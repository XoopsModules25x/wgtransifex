<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MSC_YOURNAMEC', 'Ваше имя: ');
define('_MSC_YOUREMAILC', 'Ваш Email: ');
define('_MSC_FRIENDNAMEC', 'Имя друга: ');
define('_MSC_FRIENDEMAILC', 'Email друга: ');
define('_MSC_RECOMMENDSITE', 'Рекомендовать этот сайт другу');
// %s is your site name
define('_MSC_INTSITE', 'Интересный сайт: %s');
define('_MSC_REFERENCESENT', 'Ссылка на наш сайт была отправлена Вашему другу. Спасибо!');
define('_MSC_ENTERYNAME', 'Пожалуйста, введите Ваше имя');
define('_MSC_ENTERFNAME', 'Пожалуйста, введите имя Вашего друга');
define('_MSC_ENTERFMAIL', 'Пожалуйста, введите email Вашего друга');
define('_MSC_NEEDINFO', 'Вам нужно ввести необходимую информацию!');
define('_MSC_INVALIDEMAIL1', 'Адрес электронной почты не является действительным адресом.');
define('_MSC_INVALIDEMAIL2', 'Пожалуйста, проверьте адрес и попробуйте снова.');
define('_MSC_AVAVATARS', 'Доступные аватары');
define('_MSC_SMILIES', 'Смайлы');
define('_MSC_CLICKASMILIE', 'Нажмите на смайл, чтобы вставить его в сообщение.');
define('_MSC_CODE', 'Код');
define('_MSC_EMOTION', 'Эмоция');

define('_MSC_CLICK_TO_OPEN_IMAGE', 'Нажмите, чтобы посмотреть оригинал изображения в новом окне');
define('_MSC_RESIZED_IMAGE', 'Уменьшенное изображение');
define('_MSC_ORIGINAL_IMAGE', 'Исходное изображение');
