<?php
// _LANGCODE: ru
// _CHARSET : UTF-8
// Переводчик: Команда переводчиков XOOPS 

define('LEGEND_XOOPS_PATHS', 'Физические пути XOOPS');
define('LEGEND_DATABASE', 'Набор символов БД');

define('XOOPS_LIB_PATH_LABEL', 'Каталог библиотек XOOPS');
define('XOOPS_LIB_PATH_HELP', 'Физический путь к каталогу библиотеки XOOPS без конечной косой черты для прямой совместимости. Найдите папку ' . XOOPS_ROOT_PATH . '  чтобы обезопасить ее.');
define('XOOPS_DATA_PATH_LABEL', 'Каталог файлов данных XOOPS');
define('XOOPS_DATA_PATH_HELP', 'Физический путь к лучшая файлы данных (каталог, доступный для записи) без Слэша, для обеспечения совместимости. Найдите папку ' . XOOPS_ROOT_PATH . ' чтобы обезопасить ее.');

define('DB_COLLATION_LABEL', 'Набор символов базы данных и параметры сортировки');
define('DB_COLLATION_HELP', "Начиная с версии 4.12 MySQL поддерживает пользовательский набор символов и параметры сортировки. Однако это сложнее, чем ожидалось, поэтому не вносите никаких изменений, если Вы не уверены в своем выборе.");
define('DB_COLLATION_NOCHANGE', 'Не менять');

define('XOOPS_PATH_FOUND', 'Путь найден.');
define('ERR_COULD_NOT_ACCESS', 'Не удалось получить доступ к указанной папке. Пожалуйста, убедитесь, что она существует и читается сервером.');
define('CHECKING_PERMISSIONS', 'Проверка прав доступа к файлам и каталогам...');
define('ERR_NEED_WRITE_ACCESS', 'Серверу должен быть предоставлен доступ на запись к следующим файлам и папкам<br>(например, <em>chmod 777 directory_name</em> на сервере UNIX/LINUX)');
define('IS_NOT_WRITABLE', '%s не доступен для записи.');
define('IS_WRITABLE', '%s доступен для записи.');
define('ERR_COULD_NOT_WRITE_MAINFILE', 'Ошибка записи содержимого в mainfile.php, запишите содержимое в mainfile.php вручную.');