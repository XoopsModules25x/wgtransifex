tinyMCE.addI18n('en.xoopscode',{
code_desc:"Вставить код"
});