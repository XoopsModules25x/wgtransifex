/**
 */

tinyMCE.addI18n('ru.xoopsmlcontent_dlg',{
title : 'Вставить многоязычный контент',
subtitle : 'Выберите язык и введите / вставьте содержимое в поле ниже:',
sellang : 'Выберите язык',
chooselang : 'Вы должны выбрать язык',
maxstring : ' cимвол(ы) %maxchar% ',
alertmaxstring : 'Вы достигли максимального количества символов',
delta_width : 100,
delta_height : 100
});