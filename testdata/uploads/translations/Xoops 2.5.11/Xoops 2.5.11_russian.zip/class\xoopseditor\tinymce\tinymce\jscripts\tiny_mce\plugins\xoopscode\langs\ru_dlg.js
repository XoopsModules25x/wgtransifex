tinyMCE.addI18n('ru.xoopscode_dlg',{
xoopscode_title:"Вставить код",
xoopscode_desc:"Вставить код",
 xoopscode_sub:"Вставьте код, который Вы хотите вставить, в поле ниже:"
});