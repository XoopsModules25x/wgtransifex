<?php
/**
 * Installer main english strings declaration file
 *
 * @copyright    (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license          GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * @package          installer
 * @since            2.3.0
 * @author           Haruki Setoyama  <haruki@planewave.org>
 * @author           Kazumi Ono <webmaster@myweb.ne.jp>
 * @author           Skalpa Keo <skalpa@xoops.org>
 * @author           Taiwen Jiang <phppp@users.sourceforge.net>
 * @author           dugris <dugris@frxoops.org>
 */
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('SHOW_HIDE_HELP', 'Показать/скрыть текст справки');
// License
define('LICENSE_NOT_WRITEABLE', 'Файл лицензии "%s" не записан!');
define('LICENSE_IS_WRITEABLE', '%s лицензия записана.');
// Configuration check page
define('SERVER_API', 'API сервера');
define('PHP_EXTENSION', '%s расширение');
define('CHAR_ENCODING', 'Кодировка символов');
define('XML_PARSING', 'Разбор XML');
define('REQUIREMENTS', 'Требования');
define('_PHP_VERSION', 'Версия PHP');
define('RECOMMENDED_SETTINGS', 'Рекомендуемые настройки');
define('RECOMMENDED_EXTENSIONS', 'Рекомендуемые расширения');
define('SETTING_NAME', 'Имя параметра');
define('RECOMMENDED', 'Рекомендуемые');
define('CURRENT', 'Текущий');
define('RECOMMENDED_EXTENSIONS_MSG', 'Эти расширения не требуются для нормального использования, но могут потребоваться для изучения
    Некоторые особенности (например, поддержка нескольких языков или RSS). Таким образом, рекомендуется установить их.');
define('NONE', 'Нет');
define('SUCCESS', 'Успешно');
define('WARNING', 'Предупреждение');
define('FAILED', 'Неудачно');
// Titles (main and pages)
define('XOOPS_INSTALL_WIZARD', 'Мастер установки XOOPS');
define('LANGUAGE_SELECTION', 'Выбор языка');
define('LANGUAGE_SELECTION_TITLE', 'Выберите Ваш язык');        // L128
define('INTRODUCTION', 'Вступление');
define('INTRODUCTION_TITLE', 'Добро пожаловать в мастер установки XOOPS');        // L0
define('CONFIGURATION_CHECK', 'Проверка конфигурации');
define('CONFIGURATION_CHECK_TITLE', 'Проверка конфигурации сервера');
define('PATHS_SETTINGS', 'Настройки контуров');
define('PATHS_SETTINGS_TITLE', 'Настройки контуров');
define('DATABASE_CONNECTION', 'Подключение к базе данных');
define('DATABASE_CONNECTION_TITLE', 'Подключение к базе данных');
define('DATABASE_CONFIG', 'Настройка базы данных');
define('DATABASE_CONFIG_TITLE', 'Настройка базы данных');
define('CONFIG_SAVE', 'Сохранить конфигурацию');
define('CONFIG_SAVE_TITLE', 'Сохранение конфигурации Вашей системы');
define('TABLES_CREATION', 'Создание таблиц');
define('TABLES_CREATION_TITLE', 'Создание таблиц базы данных');
define('INITIAL_SETTINGS', 'Начальные настройки');
define('INITIAL_SETTINGS_TITLE', 'Введите начальные настройки');
define('DATA_INSERTION', 'Вставка данных');
define('DATA_INSERTION_TITLE', 'Сохранение настроек в базе данных');
define('WELCOME', 'Добро пожаловать');
define('WELCOME_TITLE', 'Добро пожаловать на сайт XOOPS');        // L0
// Settings (labels and help text)
define('XOOPS_PATHS', 'Физические пути XOOPS ');
define('XOOPS_URLS', 'Веб-сайты');
define('XOOPS_ROOT_PATH_LABEL', 'Корневой путь XOOPS');
define('XOOPS_ROOT_PATH_HELP', 'Физический путь к каталогу документов XOOPS (обслуживается) БЕЗ конечной косой черты');
define('XOOPS_LIB_PATH_LABEL', 'Каталог библиотеки XOOPS');
define('XOOPS_LIB_PATH_HELP', 'Physical path to the XOOPS library directory WITHOUT trailing slash, for forward compatibility. Locate the folder out of ' . XOOPS_ROOT_PATH_LABEL . ' to make it secure.');
define('XOOPS_DATA_PATH_LABEL', 'Каталог файлов XOOPS');
define('XOOPS_DATA_PATH_HELP', 'Physical path to the XOOPS data files (writable) directory WITHOUT trailing slash, for forward compatibility. Locate the folder out of ' . XOOPS_ROOT_PATH_LABEL . ' to make it secure.');
define('XOOPS_URL_LABEL', 'Расположение сайта (URL)'); // L56
define('XOOPS_URL_HELP', 'Основной URL-адрес, который будет использоваться для доступа к Вашему XOOPS'); // L58
define('LEGEND_CONNECTION', 'Подключение к серверу');
define('LEGEND_DATABASE', 'База данных'); // L51
define('DB_HOST_LABEL', 'Имя хоста сервера');    // L27
define('DB_HOST_HELP', 'Имя хоста сервера базы данных. Если вы не уверены, <em>localhost</em> работает в большинстве случаев'); // L67
define('DB_USER_LABEL', 'Имя пользователя');    // L28
define('DB_USER_HELP', 'Имя учетной записи пользователя, которая будет использоваться для подключения к серверу базы данных'); // L65
define('DB_PASS_LABEL', 'Пароль');    // L52
define('DB_PASS_HELP', 'Пароль учетной записи пользователя Вашей базы данных'); // L68
define('DB_NAME_LABEL', 'Название базы данных');    // L29
define('DB_NAME_HELP', 'Имя базы данных на хосте. Установщик попытается создать базу данных, если не существует'); // L64
define('DB_CHARSET_LABEL', 'Набор символов базы данных');
define('DB_CHARSET_HELP', 'MySQL включает поддержку набора символов, которая позволяет хранить данные с помощью множества наборов символов и выполнять сравнения в соответствии с различными сортировками.');
define('DB_COLLATION_LABEL', 'Сопоставление базы данных');
define('DB_COLLATION_HELP', 'Сортировка - это набор правил для сравнения символов в наборе символов.');
define('DB_PREFIX_LABEL', 'Префикс таблицы');    // L30
define('DB_PREFIX_HELP', 'Этот префикс будет добавлен ко всем новым таблицам, созданным для предотвращения конфликтов имен в базе данных. Если вы не уверены, просто сохраните настройки по умолчанию'); // L63
define('DB_PCONNECT_LABEL', 'Использовать постоянное соединение');    // L54
define('DB_PCONNECT_HELP', "По умолчанию «Нет». Оставьте поле пустым, если Вы не уверены"); // L69
define('DB_DATABASE_LABEL', 'База данных');
define('LEGEND_ADMIN_ACCOUNT', 'Учетная запись администратора');
define('ADMIN_LOGIN_LABEL', 'Вход для администратора'); // L37
define('ADMIN_EMAIL_LABEL', 'Админская электронная почта'); // L38
define('ADMIN_PASS_LABEL', 'Пароль администратора'); // L39
define('ADMIN_CONFIRMPASS_LABEL', 'Подтвердите пароль'); // L74
// Buttons
define('BUTTON_PREVIOUS', 'Предыдущий'); // L42
define('BUTTON_NEXT', 'Продолжить'); // L47
// Messages
define('XOOPS_FOUND', '%s найдено');
define('CHECKING_PERMISSIONS', 'Проверка прав на файл и каталог ...'); // L82
define('IS_NOT_WRITABLE', '%s НЕ записывается.'); // L83
define('IS_WRITABLE', '%s доступен для записи.'); // L84
define('XOOPS_PATH_FOUND', 'Путь найден.');
//define('READY_CREATE_TABLES', 'Таблиц XOOPS не обнаружено.<br>Теперь установщик готов к созданию системных таблиц XOOPS.');
define('XOOPS_TABLES_FOUND', 'Системные таблицы XOOPS уже существуют в Вашей базе данных.'); // L131
define('XOOPS_TABLES_CREATED', 'Созданы системные таблицы XOOPS.');
//define('READY_INSERT_DATA', 'Теперь установщик готов вставить исходные данные в Вашу базу данных.');
//define('READY_SAVE_MAINFILE', 'Теперь установщик готов сохранить указанные параметры, в <em>mainfile.php</em>.');
define('SAVED_MAINFILE', 'Настройки сохранены');
define('SAVED_MAINFILE_MSG', 'Установщик сохранил указанные параметры в <em>mainfile.php</em> и <em>secure.php</em>.');
define('DATA_ALREADY_INSERTED', 'Данные XOOPS найдены в базе данных.');
define('DATA_INSERTED', 'Исходные данные были вставлены в базу данных.');
// %s is database name
define('DATABASE_CREATED', 'База данных %s создана!'); // L43
// %s is table name
define('TABLE_NOT_CREATED', 'Не удалось создать таблицу %s'); // L118
define('TABLE_CREATED', 'Таблица %s создана.'); // L45
define('ROWS_INSERTED', '%d записи, вставленные в таблицу %s.'); // L119
define('ROWS_FAILED', 'Ошибка при вставке %d записей в таблицу %s.'); // L120
define('TABLE_ALTERED', 'Таблица %s обнавлена.'); // L133
define('TABLE_NOT_ALTERED', 'Ошибка обновления таблицы %s.'); // L134
define('TABLE_DROPPED', 'Таблица %s с ошибкой.'); // L163
define('TABLE_NOT_DROPPED', 'Не удалось удалить таблицу %s.'); // L164
// Error messages
define('ERR_COULD_NOT_ACCESS', 'Не удалось получить доступ к указанной папке. Убедитесь, что он существует и доступен для чтения сервером.');
define('ERR_NO_XOOPS_FOUND', 'В указанной папке не обнаружена XOOPS.');
define('ERR_INVALID_EMAIL', 'Неверный Email'); // L73
define('ERR_REQUIRED', 'Требуется информация.'); // L41
define('ERR_PASSWORD_MATCH', 'Эти два пароля не совпадают');
define('ERR_NEED_WRITE_ACCESS', 'Серверу должен быть предоставлен доступ на запись к следующим файлам и папкам<br>(i.e. <em>chmod 775 directory_name</em> on a UNIX/LINUX server)<br> если они не доступны или не созданы, создайте вручную и установите соответствующие разрешения.');
define('ERR_NO_DATABASE', 'Не удалось создать базу данных. Для получения дополнительной информации обратитесь к администратору сервера.'); // L31
define('ERR_NO_DBCONNECTION', 'Не удалось подключиться к серверу базы данных.'); // L106
define('ERR_WRITING_CONSTANT', 'Ошибка постоянной записи %s.'); // L122
define('ERR_COPY_MAINFILE', 'Не удалось скопировать файл в %s');
define('ERR_WRITE_MAINFILE', 'Не удалось записать в %s. Проверьте разрешение файла и повторите попытку.');
define('ERR_READ_MAINFILE', 'Не смог открыть %s для чтения');
define('ERR_INVALID_DBCHARSET', "Кодировка '%s' не поддерживается.");
define('ERR_INVALID_DBCOLLATION', "Сортировка '%s' не поддерживается.");
define('ERR_CHARSET_NOT_SET', 'Набор символов по умолчанию для базы данных XOOPS не установлен.');
define('_INSTALL_CHARSET', 'UTF-8');
define('SUPPORT', 'Поддержка');
define('LOGIN', 'Аутентификация');
define('LOGIN_TITLE', 'Аутентификация');
define('USER_LOGIN', 'Вход для администратора');
define('USERNAME', 'Имя пользователя:');
define('PASSWORD', 'Пароль :');
define('ICONV_CONVERSION', 'Преобразование набора символов');
define('ZLIB_COMPRESSION', 'Сжатие Zlib');
define('IMAGE_FUNCTIONS', 'Функции изображения');
define('IMAGE_METAS', 'Метаданные изображения (exif)');
define('FILTER_FUNCTIONS', 'Функции фильтра');
define('ADMIN_EXIST', 'Учетная запись администратора уже существует.');
define('CONFIG_SITE', 'Конфигурация сайта');
define('CONFIG_SITE_TITLE', 'Конфигурация сайта');
define('MODULES', 'Установка модулей');
define('MODULES_TITLE', 'Установка модулей');
define('THEME', 'Выберите тему');
define('THEME_TITLE', 'Выберите тему по умолчанию');
define('INSTALLED_MODULES', 'Были установлены следующие модули.');
define('NO_MODULES_FOUND', 'Никаких модулей не найдено.');
define('NO_INSTALLED_MODULES', 'Модуль не установлен.');
define('THEME_NO_SCREENSHOT', 'Не найдено скриншотов');
define('IS_VALOR', ' => ');
// password message
define('PASSWORD_LABEL', 'Надежность пароля');
define('PASSWORD_DESC', 'Пароль не введен');
define('PASSWORD_GENERATOR', 'Генератор паролей');
define('PASSWORD_GENERATE', 'Генерировать');
define('PASSWORD_COPY', 'Копировать');
define('PASSWORD_VERY_WEAK', 'Очень слабый');
define('PASSWORD_WEAK', 'Слабый');
define('PASSWORD_BETTER', 'Лучше');
define('PASSWORD_MEDIUM', 'Средний');
define('PASSWORD_STRONG', 'Сильный');
define('PASSWORD_STRONGEST', 'Самый сильный');
//2.5.7
define('WRITTEN_LICENSE', 'Написал XOOPS %s Лицензионный ключ: <strong>%s</strong>');
//2.5.8
define('CHMOD_CHGRP_REPEAT', 'Retry');
define('CHMOD_CHGRP_IGNORE', 'Использовать в любом случае');
define('CHMOD_CHGRP_ERROR', 'Установщик может не записать файл конфигурации %1$s.<p>PHP пишет файлы под пользователем %2$s и группа %3$s.<p>Каталог %4$s/ пользователь %5$s и группа %6$s');
//2.5.9
define("CURL_HTTP", "Библиотека URL-адресов клиентов (cURL)");
define('XOOPS_COOKIE_DOMAIN_LABEL', 'Домен для файлов cookie для веб-сайта');
define('XOOPS_COOKIE_DOMAIN_HELP', 'Домен для установки файлов cookie. Может быть пустым, полный хост из URL (www.example.com) или зарегистрированного домена без субдоменов (example.com), чтобы делиться между субдоменами (www.example.com и blog.example.com.)');
define('INTL_SUPPORT', 'Функции интернационализации');
define('XOOPS_SOURCE_CODE', "XOOPS на GitHub");
define('XOOPS_INSTALLING', 'Установка');
define('XOOPS_ERROR_ENCOUNTERED', 'Ошибка');
define('XOOPS_ERROR_SEE_BELOW', 'См. ниже сообщения.');
define('MODULES_AVAILABLE', 'Доступные модули');
define('INSTALL_THIS_MODULE', 'Добавить %s');
