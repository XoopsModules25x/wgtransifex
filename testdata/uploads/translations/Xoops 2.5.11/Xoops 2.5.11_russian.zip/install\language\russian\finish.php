<?php
//
// _LANGCODE: ru
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

$content .= "<h3>Твой сайт</h3>
<p>Теперь Вы можете получить доступ к <a href='../index.php'>главной странице Вашего сайта</a>.</p>
<h3>Поддержка</h3>
<p>Визит <a href='http://xoops.org/' rel='external'>The XOOPS Project</a></p>
<p><strong>Внимание:</strong> Ваш сайт в настоящее время содержит минимальный функционал.
Пожалуйста, посетите <a href='http://xoops.org/' rel='external' title='XOOPS Web Application System'>xoops.org</a>
чтобы узнать больше о расширении XOOPS для представления текстовых страниц, фотогалерей, форумов и многого другого,
 <em>модули</em> а также настроить внешний вид Вашего XOOPS с помощью <em>тем</em>.</p>
";

$content .= "<h3>Конфигурация безопасности</h3>
<p>Установщик попытается настроить Ваш сайт на соображения безопасности. Пожалуйста, дважды проверьте, чтобы убедиться:
<div class='confirmMsg'>
<em>mainfile.php</em> только для чтения.<br>
Удалена папка <em>{$installer_modified}</em> (или папка <em>install</em> была автоматически переименована)  с Вашего сервера.
</div>
</p>
";