<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license             GNU GPL 2 (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_AVATAR_MANAGER', 'Управление аватарами');
define('_AM_SYSTEM_AVATAR_MAIN', 'Главный');
define('_AM_SYSTEM_AVATAR_SYSTEM', 'Системные аватары');
define('_AM_SYSTEM_AVATAR_CUSTOM', 'Пользовательские аватары');
define('_AM_SYSTEM_AVATAR_ADD', 'Добавить аватар');
define('_AM_SYSTEM_AVATAR_EDIT', 'Редактировать аватар');
define('_AM_SYSTEM_AVATAR_DELETE', 'Удалить аватар');
// Main
define('_AM_SYSTEM_AVATAR_MULTIUPLOAD', 'Множественная загрузка');
// Infos
define('_AM_SYSTEM_AVATAR_ERROR', 'Ошибки');
define('_AM_SYSTEM_AVATAR_USERS', 'Пользователи, использующие этот аватар');
define('_AM_SYSTEM_AVATAR_USE_FILE', 'Выберите файлы: %s');
define('_AM_SYSTEM_AVATAR_UPLOAD', 'Загрузить:');
// Messages
define('_AM_SYSTEM_AVATAR_FAILDEL', 'Ошибка удаления аватара %s из базы данных');
define('_AM_SYSTEM_AVATAR_SUREDEL', 'Вы уверены, удалить этот аватар?');
// Tips
define('_AM_SYSTEM_AVATAR_TIPS', "
<ul id='newsticker' class='newsticker'>
<li>Управление системными и пользовательскими аватарами</li>
<li>Участники сайта могут создавать свои собственные онлайн картинки, называются аватарами.<br />Эта опция может быть отключена от системы предпочтений пользователя.</li>
</ul>");
