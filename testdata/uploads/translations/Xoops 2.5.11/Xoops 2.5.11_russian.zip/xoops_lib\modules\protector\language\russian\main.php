<?php
define('_MD_PROTECTOR_YOUAREBADIP', 'Вы зарегистрированы как BAD_IP в Protector.<br>');
define('_MD_PROTECTOR_FMT_JAILINFO', 'Это ограничение истекает %s');
define('_MD_PROTECTOR_FMT_JAILTIME', 'Y-m-j H:i:s');
define('_MD_PROTECTOR_BANDWIDTHLIMITED', 'Сейчас сайт занят. Пожалуйста, попробуйте позднее.');
define('_MD_PROTECTOR_TURNJAVASCRIPTON', 'Включить JavaScript');
define('_MD_PROTECTOR_DENYBYRBL', 'Защитник отклоняет Ваш пост, потому что ваш IP-адрес зарегистрирован в RBL');
define('_MD_PROTECTOR_FMT_REGISTER_MORATORIUM', 'Отправьте его снова %s минут спустя (Anti-SPAMMING, извините).');
