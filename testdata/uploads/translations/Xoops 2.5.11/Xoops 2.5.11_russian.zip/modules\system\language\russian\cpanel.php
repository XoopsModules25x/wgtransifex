<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MD_AM_VRSN', 'Версия');
define('_MD_AM_FINDUSER', 'Найти пользователей');
define('_MD_CPANEL_NEWS', 'Новости');
define('_MD_CPANEL_NEWS_DESC', 'Новости XOOPS');
define('_MD_CPANEL_PROJECT', 'Проект');
define('_MD_CPANEL_PROJECT_DESC', 'XOOPS Project website');
define('_MD_CPANEL_COMMUNITY', 'Сообщество');
define('_MD_CPANEL_COMMUNITY_DESC', 'XOOPS Official Community website');
define('_MD_CPANEL_LOCAL', 'Локальная поддержка');
define('_MD_CPANEL_LOCAL_DESC', 'XOOPS Certified Local Support websites');
define('_MD_CPANEL_OVERVIEW', 'Обзор системы');
define('_MD_CPANEL_PHPEXTENSIONS', 'Загруженные расширения PHP');
define('_MD_CPANEL_VERSION', '%s версия');
define('_MD_CPANEL_QUICKLINKS', 'Быстрые ссылки');
define('_MD_CPANEL_SITE_ADMINISTRATION', '%s администрация');
// for help page
define('_MD_CPANEL_HELPCENTER', 'Добро пожаловать в XOOPS справочный центр');
