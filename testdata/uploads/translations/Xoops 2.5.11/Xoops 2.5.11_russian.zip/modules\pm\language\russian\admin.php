<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PM_AM_PRUNE', 'Очистка');
define('_PM_AM_PRUNEAFTER', 'Удалять сообщения, которые разместил после этой даты (оставьте пустым, без всякой даты начала)');
define('_PM_AM_PRUNEBEFORE', 'Удалять сообщения, до этой даты (оставьте поле пустым без даты окончания)');
define('_PM_AM_ONLYREADMESSAGES', 'PRUNE только для чтения сообщений');
define('_PM_AM_INCLUDESAVE', "Включите сообщения в пользователей' \"save\" папки");
define('_PM_AM_NOTIFYUSERS', 'Уведомить пострадавших пользователей о сокращении?');
define('_PM_AM_MESSAGESPRUNED', '%u сообщения обрезано');
define('_PM_AM_ERRORWHILEPRUNING', 'Произошла ошибка во время сокращении');
