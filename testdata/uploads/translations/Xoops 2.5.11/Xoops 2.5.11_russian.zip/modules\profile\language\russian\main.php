<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PROFILE_MA_REGISTER_NOTGROUP', 'Новый пользователь не зарегистрирован в соответствующих группах.');
define('_PROFILE_MA_FINISH_LOGIN', 'Ваша учетная запись была успешно создана, пожалуйста, нажмите, чтобы войти в систему.');
define('_PROFILE_MA_REGISTER_FINISH', 'Благодарим за регистрацию');
define('_PROFILE_MA_REGISTER_STEPS', 'Регистрация шаги:');
define('_PROFILE_MA_DEFAULT', 'Основная информация');
define('_PROFILE_MA_ERRORDURINGSAVE', 'Ошибка во время сохранения');
define('_PROFILE_MA_NOSTEPSAVAILABLE', 'Регистрация не допускается в данный момент, пожалуйста, зайдите позже.');
define('_PROFILE_MA_EXPIRED', 'Процесс истек, вернитесь, пожалуйста, попробуйте еще раз.');
define('_PROFILE_MA_RECENTACTIVITY', 'Последние действия');
define('_PROFILE_MA_THEME', 'Темы');
define('_PROFILE_MA_ACTIVATE', 'Активировать');
define('_PROFILE_MA_DEACTIVATE', 'Деактивировать');
define('_PROFILE_MA_SENDPM', 'Отправить сообщение');
//changepass.php
define('_PROFILE_MA_CHANGEPASSWORD', 'Изменить пароль');
define('_PROFILE_MA_PASSWORDCHANGED', 'Пароль успешно изменен');
define('_PROFILE_MA_OLDPASSWORD', 'Текущий пароль');
define('_PROFILE_MA_NEWPASSWORD', 'Новый пароль');
define('_PROFILE_MA_WRONGPASSWORD', 'Старый пароль неправильный');
//search.php
define('_PROFILE_MA_SORTBY', 'Сортировать по');
define('_PROFILE_MA_ORDER', 'Порядок');
define('_PROFILE_MA_PERPAGE', 'Пользователи на странице');
define('_PROFILE_MA_LATERTHAN', '%s позднее, чем');
define('_PROFILE_MA_EARLIERTHAN', '%s раньше, чем');
define('_PROFILE_MA_LARGERTHAN', '%s больше, чем');
define('_PROFILE_MA_SMALLERTHAN', '%s меньше, чем');
define('_PROFILE_MA_NOUSERSFOUND', 'Пользователи не найдены');
define('_PROFILE_MA_RESULTS', 'Результаты поиска');
define('_PROFILE_MA_SEARCH', 'Поиск пользователей');
//changemail.php
define('_PROFILE_MA_CHANGEMAIL', 'Изменить Email');
define('_PROFILE_MA_NEWMAIL', 'Новый Email адресс');
define('_PROFILE_MA_NEWEMAIL', 'Новый email адрес в %s');
define('_PROFILE_MA_EMAILCHANGED', 'Ваш адрес Email был изменен');
define('_PROFILE_MA_SITEDEFAULT', 'По умолчанию сайта');
define('_PROFILE_MA_USERINFO', 'Профиль пользователя');
define('_PROFILE_MA_REGISTER', 'Форма регистрации');
define('_PROFILE_MA_ACTUS', 'Активные пользователи: %s');
define('_PROFILE_MA_FOUNDUSER', '%s найдено пользователей');
