<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PROFILE_MI_NAME', 'Профиль пользователя');
define('_PROFILE_MI_DESC', 'Модуль для управления полей профилей пользователей');
//Main menu links
define('_PROFILE_MI_EDITACCOUNT', 'Редактировать профиль');
define('_PROFILE_MI_CHANGEPASS', 'Изменить пароль');
define('_PROFILE_MI_CHANGEMAIL', 'Изменить Email');
//Admin links
define('_PROFILE_MI_INDEX', 'Главная');
define('_PROFILE_MI_CATEGORIES', 'Категории');
define('_PROFILE_MI_FIELDS', 'Поля');
define('_PROFILE_MI_USERS', 'Пользователи');
define('_PROFILE_MI_STEPS', 'Регистрация Этапы');
define('_PROFILE_MI_PERMISSIONS', 'Права доступа');
//User Profile Category
define('_PROFILE_MI_CATEGORY_TITLE', 'Профиль пользователя');
define('_PROFILE_MI_CATEGORY_DESC', 'Для тех пользовательских полей');
//User Profile Fields
define('_PROFILE_MI_URL_TITLE', 'Веб сайт');
//Configuration categories
define('_PROFILE_MI_CAT_SETTINGS', 'Основные настройки');
define('_PROFILE_MI_CAT_SETTINGS_DSC', ');
define('_PROFILE_MI_CAT_USER', 'Пользовательские настройки');
define('_PROFILE_MI_CAT_USER_DSC', ');
//Configuration items
define('_PROFILE_MI_PROFILE_SEARCH', 'Показать последние мероприятия по профилю пользователя');
//Pages
define('_PROFILE_MI_PAGE_INFO', 'Информация о пользователе');
define('_PROFILE_MI_PAGE_EDIT', 'Изменить пользователя');
define('_PROFILE_MI_PAGE_SEARCH', 'Поиск');
define('_PROFILE_MI_STEP_BASIC', 'Базовый');
define('_PROFILE_MI_STEP_COMPLEMENTARY', 'Продвинутый');
define('_PROFILE_MI_CATEGORY_PERSONAL', 'Личный');
define('_PROFILE_MI_CATEGORY_MESSAGING', 'Обмен сообщениями');
define('_PROFILE_MI_CATEGORY_SETTINGS', 'Настройки');
define('_PROFILE_MI_CATEGORY_COMMUNITY', 'Сообщество');
define('_PROFILE_MI_NEVER_LOGGED_IN', 'Никогда не вошли в систему');
//1.62
define('_PROFILE_MI_ABOUT', 'О модуле');
define('_PROFILE_MI_HOME', 'Главная');
//1.86
define('_PROFILE_MI_PROFILE_CAPTCHA_STEP1', 'Использовать Captcha после второй стадии регистрации?');
define('_PROFILE_MI_PROFILE_CAPTCHA_STEP1_DESC', "Выберите 'Да', чтобы добавить дополнительные меры против регистрации спам ботов");
