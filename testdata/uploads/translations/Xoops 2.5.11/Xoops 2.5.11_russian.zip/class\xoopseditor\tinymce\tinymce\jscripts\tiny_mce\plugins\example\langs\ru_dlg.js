tinyMCE.addI18n('ru.example_dlg',{
 title : 'Это всего лишь пример названия'
});