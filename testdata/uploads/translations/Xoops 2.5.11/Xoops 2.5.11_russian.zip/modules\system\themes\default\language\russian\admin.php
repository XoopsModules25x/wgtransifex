<?php
//
define('_OXYGEN_SYSOPTIONS', 'Параметры системы');
define('_OXYGEN_INSTALLEDMODULES', 'Установленные модули');
define('_OXYGEN_XOOPSTHEMES', 'Темы XOOPS ');
define('_OXYGEN_XOOPSMODULES', 'Модули XOOPS');
define('_OXYGEN_INTERESTSITES', 'Ссылки');
define('_OXYGEN_LOCALSUPPORT', 'Локальная поддержка');
define('_OXYGEN_NEWS', 'Новости Xoops');
define('_OXYGEN_WEBSITE', 'Сообщество');
define('_OXYGEN_SOURCEFORGE', 'Источник');
define('_OXYGEN_VERSION', 'Версия');
define('_OXYGEN_VERSION_XOOPS', 'Версия XOOPS');
define('_OXYGEN_VERSION_PHP', 'Версия PHP');
define('_OXYGEN_VERSION_MYSQL', 'Версия mySQL');
define('_OXYGEN_Server_API', 'API сервера');
define('_OXYGEN_OS', 'OS');
define('_OXYGEN_ABOUT', 'О XOOPS');
define('_OXYGEN_ABOUT_TEXT', 'Прочтите <a href="http://www.xoops.org/modules/wfchannel/" rel="external" title="All about XOOPS">о XOOPS</a> для более подробной информации.');
define('_OXYGEN_XOOPS_LINKS', 'Ссылки XOOPS');
define('_OXYGEN_XOOPSPROJECT', 'Проект XOOPS');
define('_OXYGEN_XOOPSCORE', 'XOOPS Core');
define('_OXYGEN_XOOPSTHEME', 'Темы XOOPS ');
define('_OXYGEN_XOOPSWIKI', 'XOOPS Wiki');
define('_OXYGEN_XOOPSBOOKS', 'Книги XOOPS');
define('_OXYGEN_NEWMODULE', 'Новые модули');
define('_OXYGEN_XOOPSFAQ', 'XOOPS FAQ');
define('_OXYGEN_CODESVN', 'Репозиторий кода');
define('_OXYGEN_REPORTBUG', 'Сообщить об ошибке');
define('_OXYGEN_SITEPREF', 'Настройки');
define('_OXYGEN_GENERAL', 'Основные настройки');
define('_OXYGEN_USERSETTINGS', 'Настройки информации пользователя');
define('_OXYGEN_METAFOOTER', 'МЕТА-тэги и нижний колонтитул');
define('_OXYGEN_CENSOR', 'Параметры цензуры слов');
define('_OXYGEN_SEARCH', 'Опции поиска');
define('_OXYGEN_MAILER', 'Настрока Email');
define('_OXYGEN_AUTHENTICATION', 'Параметры проверки подлинности');
define('_OXYGEN_MODULESETTINGS', 'Системные настройки модуля');
//Add for styles name
define('_OXYGEN_SILVER', 'Серебряный');
define('_OXYGEN_DARK', 'Темно');
define('_OXYGEN_ORANGE', 'Оранжевый');
//Add 10 des
define('_OXYGEN_XOOPS_LICENSE', 'Лицензия XOOPS');
define('_OXYGEN_RSS', 'Новостная лента RSS');
define('_OXYGEN_ADMINISTRATION', 'Администрация XOOPS');
define('_OXYGEN_UPTOP', 'Вверх');
//Add help
define('_OXYGEN_HELP_1', 'Как создать контент с помощью XOOPS?');
define('_OXYGEN_HELP_DESC_1', 'Чтобы создать контент, вы должны сначала установить модуль, например, <a href="https://github.com/XoopsModules25x/publisher" rel="external">Publisher</a> или <a href="https://github.com/XoopsModules25x/news" rel="external">News</a> модуль. Чтобы узнать больше о модулях XOOPS <a href="modules/system/help.php?mid=1&page=modulesadmin">нажмите здесь</a>');
define('_OXYGEN_HELP_2', 'Что такое блок?');
define('_OXYGEN_HELP_DESC_2', 'Блоки могут предоставлять дополнительный / конкретный контент из установленных модулей. Могут быть и пользовательские блоки, которые могут содержать текст, код JS, текст в формате HTML, изображения и т. Д. Содержимое этих блоков может быть отформатировано индивидуально или может наследовать форматирование с Веб-сайта. (<a href="modules/system/help.php?mid=1&page=blocksadmin">больше ...</a>)');
define('_OXYGEN_HELP_3', 'Как я могу найти больше помощи?');
define('_OXYGEN_HELP_DESC_3', 'Если вам нужна дополнительная помощь и информация для использования XOOPS, вы можете использовать <a href="modules/system/help.php">страницы справки </a> в системном модуле или использовать <a href="http://www.xoops.org/modules/xoopspartners/" rel="external">XOOPS локальные сайты поддержки </a>');
