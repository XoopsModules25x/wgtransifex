<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
define('_AM_SYSTEM_MAILUSERS_AMIFCHECKD', 'Если этот флажок установлен, все выше, а также личные сообщений будут проигнорированы');
define('_AM_SYSTEM_MAILUSERS_EMAIL', 'Email');
define('_AM_SYSTEM_MAILUSERS_GROUPIS', ' - Группа:');
define('_AM_SYSTEM_MAILUSERS_DAY', ' - Последний вход в систему (дней назад):');
define('_AM_SYSTEM_MAILUSERS_IDLEMORE', 'больше, чем X');
define('_AM_SYSTEM_MAILUSERS_IDLELESS', 'меньше, чем X');
define('_AM_SYSTEM_MAILUSERS_DATE', ' - Последний вход:');
define('_AM_SYSTEM_MAILUSERS_LASTLOGMAX', 'до');
define('_AM_SYSTEM_MAILUSERS_LASTLOGMIN', 'после');
define('_AM_SYSTEM_MAILUSERS_REGDATE', ' - Дата регистрации:');
define('_AM_SYSTEM_MAILUSERS_REGDMIN', 'после');
define('_AM_SYSTEM_MAILUSERS_REGDMAX', 'до');
define('_AM_SYSTEM_MAILUSERS_INACTIVE', 'Отправить сообщение для неактивных пользователей');
define('_AM_SYSTEM_MAILUSERS_MAILOK', 'Отправить сообщение только для пользователей, которые принимают сообщения уведомлений');
define('_AM_SYSTEM_MAILUSERS_OPTIONAL', 'Дополнительное значение');
define('_AM_SYSTEM_MAILUSERS_LIST', 'Отправить сообщение для пользователей');
define('_AM_SYSTEM_MAILUSERS_MAILBODY', ' Сообщение');
define('_AM_SYSTEM_MAILUSERS_MAILFNAME', 'От имени (только email)');
define('_AM_SYSTEM_MAILUSERS_MAILFMAIL', 'От Email (только email)');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS', 'Полезные теги:');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS1', '{X_UID} идентификатор пользователя');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS2', '{X_UNAME} имя пользователя');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS3', '{X_UEMAIL} email пользователя');
define('_AM_SYSTEM_MAILUSERS_MAILTAGS4', '{X_UACTLINK} ссылку активации пользователя');
define('_AM_SYSTEM_MAILUSERS_MAILSUBJECT', ' Тема');
define('_AM_SYSTEM_MAILUSERS_MANAGER', 'Менеджер сообщений пользователя');
define('_AM_SYSTEM_MAILUSERS_SENDNEXT', 'Следующий');
define('_AM_SYSTEM_MAILUSERS_NOUSERMATCH', 'Ни один пользователь не найден');
define('_AM_SYSTEM_MAILUSERS_PM', 'Личное сообщение');
define('_AM_SYSTEM_MAILUSERS_SENDCOMP', 'Отправка сообщения завершена.');
define('_AM_SYSTEM_MAILUSERS_SENDTO', 'Отправить');
define('_AM_SYSTEM_MAILUSERS_SENDTOUSERS', 'Отправить сообщение для пользователей, у которых:');
define('_AM_SYSTEM_MAILUSERS_SENDTOUSERS2', 'Отправить:');
define('_AM_SYSTEM_MAILUSERS_SENT', 'Отправить пользователям');
define('_AM_SYSTEM_MAILUSERS_SENTNUM', '%s - %s (всего: %s пользователей)');
define('_AM_SYSTEM_MAILUSERS_TIMEFORMAT', '(Формат yyyy-mm-dd, необязательный)');
