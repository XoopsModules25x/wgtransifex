<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_CM_TITLE', 'Заглавие');
define('_CM_MESSAGE', 'Сообщение');
define('_CM_DOSMILEY', 'Включить смайлики');
define('_CM_DOHTML', 'Включить HTML-теги');
define('_CM_DOAUTOWRAP', 'Авто обертывание');
define('_CM_DOXCODE', 'Включить коды XOOPS');
define('_CM_REFRESH', 'Обновить');
define('_CM_PENDING', 'В ожидании');
define('_CM_HIDDEN', 'Скрытый');
define('_CM_ACTIVE', 'Активный');
define('_CM_STATUS', 'Статус');
define('_CM_POSTCOMMENT', 'Опубликовать комментарий');
define('_CM_REPLIES', 'Ответы');
define('_CM_PARENT', 'Родительский');
define('_CM_TOP', 'Вверх');
define('_CM_BOTTOM', 'Вниз');
define('_CM_ONLINE', 'Online!');
define('_CM_POSTED', 'Опубликован'); // Posted date
define('_CM_UPDATED', 'Обновлённое');
define('_CM_THREAD', 'Тема');
define('_CM_POSTER', 'Автор');
define('_CM_JOINED', 'Регистрация');
define('_CM_POSTS', 'Комментарии');
define('_CM_FROM', 'Из');
define('_CM_COMDELETED', 'Комментарий(и) удален.');
define('_CM_COMDELETENG', 'Не удалось удалить комментарий.');
define('_CM_DELETESELECT', 'Удалить все свои комментарии?');
define('_CM_DELETEONE', 'Нет, удалить только этот комментарий');
define('_CM_DELETEALL', 'Да, удалить все');
define('_CM_THANKSPOST', 'Спасибо за Ваши комментарии!');
define('_CM_NOTICE', "Комментарии принадлежат автору. Мы не несем ответственности за их содержание.");
define('_CM_COMRULES', 'Правила комментариев');
define('_CM_COMAPPROVEALL', 'Комментарии всегда одобрены');
define('_CM_COMAPPROVEUSER', 'Комментарии зарегистрированных пользователей всегда утверждаются');
define('_CM_COMAPPROVEADMIN', 'Все комментарии должны быть одобрены администратором');
define('_CM_COMANONPOST', 'Разрешить анонимные комментарии?');
define('_CM_COMNOCOM', 'Отключить комментарии');
define('_CM_USER', 'Имя');
define('_CM_EMAIL', 'Email');
define('_CM_URL', 'Веб сайт');
