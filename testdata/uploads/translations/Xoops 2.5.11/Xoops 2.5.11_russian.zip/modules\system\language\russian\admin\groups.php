<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// %%%%%%    Admin Module Name  AdminGroup     %%%%%
//Nav
define('_AM_SYSTEM_GROUPS_NAV_MANAGER', 'Управление группами');
define('_AM_SYSTEM_GROUPS_NAV_LIST', 'Список групп');
define('_AM_SYSTEM_GROUPS_NAV_ADD', 'Добавить новую группу');
define('_AM_SYSTEM_GROUPS_NAV_EDIT', 'Изменить группу');
define('_AM_SYSTEM_GROUPS_NAV_DELETE', 'Удалить группу');
// Tips
define('_AM_SYSTEM_GROUPS_NAV_TIPS_1', '<ul><li>Создайте новую группу со своими собственными правами.</li><li>Изменить группу для изменения разрешений.</li></ul>');
define('_AM_SYSTEM_GROUPS_NAV_TIPS_2', '<ul><li>Изменить или создать разрешение для этой группы, все изменения будут влиять на пользователей этой группы.</li></ul>');
//Infos
define('_AM_SYSTEM_GROUPS_ACCESSRIGHTS', 'Модуль прав доступа');
define('_AM_SYSTEM_GROUPS_ACTION', 'Действие');
define('_AM_SYSTEM_GROUPS_ACTIVERIGHTS', 'Модуль прав администратора');
define('_AM_SYSTEM_GROUPS_ADD', 'Добавить новую группу');
define('_AM_SYSTEM_GROUPS_BLOCKRIGHTS', 'Блок прав доступа');
define('_AM_SYSTEM_GROUPS_CUSTOMBLOCK', 'Пользовательский блок');
define('_AM_SYSTEM_GROUPS_DELETE', 'Удалить группу');
define('_AM_SYSTEM_GROUPS_DESCRIPTION', 'Описание группы');
define('_AM_SYSTEM_GROUPS_EDIT', 'Изменить группу');
define('_AM_SYSTEM_GROUPS_ERROR_DELETE', 'Вы не можете удалить эту группу');
define('_AM_SYSTEM_GROUPS_ID', 'ID');
define('_AM_SYSTEM_GROUPS_NAME', 'Название группы');
define('_AM_SYSTEM_GROUPS_NB_USERS_BY_GROUPS', 'Количество пользователей по группам');
define('_AM_SYSTEM_GROUPS_NB_USERS_BY_GROUPS_USERS', '%s пользователь(и)');
define('_AM_SYSTEM_GROUPS_SUREDEL', 'Вы уверены, что хотите удалить эту группу?');
define('_AM_SYSTEM_GROUPS_SYSTEMRIGHTS', 'Права системного администратора');
define('_AM_SYSTEM_GROUPS_DBUPDATED', _AM_SYSTEM_DBUPDATED);
