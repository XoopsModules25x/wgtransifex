<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
// Navigation
define('_AM_SYSTEM_MODULES_ADMIN', 'Управление модулем');
define('_AM_SYSTEM_MODULES_LIST', 'Список модулей');
define('_AM_SYSTEM_MODULES_TOINSTALL', 'Установить модули');
define('_AM_SYSTEM_MODULES_VALIDATE', 'Подтвердить изменения');
define('_AM_SYSTEM_MODULES_SUBMITRES', 'Внести результат');
// Messages
define('_AM_SYSTEM_MODULES_RUSUREINS', 'Нажмите на кнопку ниже, чтобы установить этот модуль');
define('_AM_SYSTEM_MODULES_RUSUREUNINS', 'Вы уверены, что хотите удалить этот модуль?');
define('_AM_SYSTEM_MODULES_RUSUREUPD', 'Нажмите на кнопку ниже, чтобы обновить этот модуль');
define('_AM_SYSTEM_MODULES_BTOMADMIN', 'Управление модулями XOOPS');
define('_AM_SYSTEM_MODULES_INSTALLING', 'Установка ');
define('_AM_SYSTEM_MODULES_DEACTIVATE', 'Отключить ');
define('_AM_SYSTEM_MODULES_ACTIVATE', 'Активировать ');
define('_AM_SYSTEM_MODULES_UPDATING', 'Обновить ');
// Main
define('_AM_SYSTEM_MODULES_INSTALL', 'Установить');
define('_AM_SYSTEM_MODULES_UNINSTALL', 'Удалить');
define('_AM_SYSTEM_MODULES_UPDATE', 'Обновить');
define('_AM_SYSTEM_MODULES_VIEWLARGE', 'Увидеть больше');
define('_AM_SYSTEM_MODULES_VIEWLINE', 'Увидеть меньше');
// %s represents module name
define('_AM_SYSTEM_MODULES_FAILINS', 'Не удалось установить %s.');
define('_AM_SYSTEM_MODULES_FAILACT', 'Невозможно активировать %s.');
define('_AM_SYSTEM_MODULES_FAILDEACT', 'Невозможно отключить %s.');
define('_AM_SYSTEM_MODULES_FAILUPD', 'Невозможно обновить %s.');
define('_AM_SYSTEM_MODULES_FAILUNINS', 'Невозможно удалить %s.');
define('_AM_SYSTEM_MODULES_FAILORDER', 'Невозможно изменить порядок %s.');
define('_AM_SYSTEM_MODULES_FAILWRITE', 'Невозможно записать в главное меню.');
define('_AM_SYSTEM_MODULES_ALEXISTS', 'Модуль %s уже существует.');
define('_AM_SYSTEM_MODULES_ERRORSC', 'Ошибка(и):');
define('_AM_SYSTEM_MODULES_OKINS', 'Модуль %s успешно установлен.');
define('_AM_SYSTEM_MODULES_OKACT', 'Модуль %s успешно активирован.');
define('_AM_SYSTEM_MODULES_OKDEACT', 'Модуль %s успешно отключен.');
define('_AM_SYSTEM_MODULES_OKUPD', 'Модуль %s успешно обновлен.');
define('_AM_SYSTEM_MODULES_OKUNINS', 'Модуль %s успешно удален.');
define('_AM_SYSTEM_MODULES_OKORDER', 'Модуль %s успешно изменен.');
define('_AM_SYSTEM_MODULES_MODULE', 'Модуль');
define('_AM_SYSTEM_MODULES_VERSION', 'Версия');
define('_AM_SYSTEM_MODULES_LASTUP', 'Последнее обновление');
define('_AM_SYSTEM_MODULES_DEACTIVATED', 'Отключить');
define('_AM_SYSTEM_MODULES_ACTION', 'Действие');
define('_AM_SYSTEM_MODULES_MENU', 'Меню');
define('_AM_SYSTEM_MODULES_HIDE', 'Скрыть');
define('_AM_SYSTEM_MODULES_SHOW', 'Показать');
define('_AM_SYSTEM_MODULES_DUPEN', 'Дублировать запись в таблице модулей!');
define('_AM_SYSTEM_MODULES_DEACTED', 'Выбранный модуль был отключен. Теперь вы можете безопасно удалить модуль.');
define('_AM_SYSTEM_MODULES_ACTED', 'Выбранный модуль был активирован!');
define('_AM_SYSTEM_MODULES_UPDTED', 'Выбранный модуль был обновлен!');
define('_AM_SYSTEM_MODULES_SYSNO', 'Системный модуль не может быть отключен.');
define('_AM_SYSTEM_MODULES_STRTNO', 'Этот модуль устанавливается в качестве стартовой страницы по умолчанию. Пожалуйста, измените модуль запуска.');
define('_AM_SYSTEM_MODULES_ORDER', 'Порядок');
define('_AM_SYSTEM_MODULES_ORDER0', '(0 = скрывать)');
define('_AM_SYSTEM_MODULES_ACTIVE', 'Активный');
define('_AM_SYSTEM_MODULES_INACTIVE', 'Неактивный');
define('_AM_SYSTEM_MODULES_NOTINSTALLED', 'Ну установлен');
define('_AM_SYSTEM_MODULES_NOCHANGE', 'Без изменений');
define('_AM_SYSTEM_MODULES_SUBMIT', 'Отправить');
define('_AM_SYSTEM_MODULES_CANCEL', 'Отменить');
define('_AM_SYSTEM_MODULES_DBUPDATE', _AM_SYSTEM_DBUPDATED);
define('_AM_SYSTEM_MODULES_LISTUPBLKS', 'Следующие блоки будут обновлены.<br />Выберите блоки у которых содержимое (шаблон и опции) будут переписаны.<br />');
define('_AM_SYSTEM_MODULES_NEWBLKS', 'Новый блок');
define('_AM_SYSTEM_MODULES_DEPREBLKS', 'Исключенные блоки');
// Logger
define('_AM_SYSTEM_MODULES_TABLE_RESERVED', '%s зарезервированные таблицы!');
define('_AM_SYSTEM_MODULES_CREATE_TABLES', 'Создание таблиц...');
define('_AM_SYSTEM_MODULES_TABLE_CREATED', 'Table %s created');
define('_AM_SYSTEM_MODULES_INSERT_DATA', '&nbsp;&nbsp; Данные вставляются в таблицу %s');
define('_AM_SYSTEM_MODULES_INSERT_DATA_FAILD', 'Не удалось вставить %s в базу данных.');
define('_AM_SYSTEM_MODULES_INSERT_DATA_DONE', 'Данные модуля вставлены успешно.');
define('_AM_SYSTEM_MODULES_MODULEID', 'ID модуля: %s');
define('_AM_SYSTEM_MODULES_SQL_FOUND', 'SQL файл найден в %s ');
define('_AM_SYSTEM_MODULES_SQL_NOT_FOUND', 'SQL файл не найден в %s');
define('_AM_SYSTEM_MODULES_SQL_NOT_CREATE', 'ОШИБКА: Не удалось создать %s ');
define('_AM_SYSTEM_MODULES_SQL_NOT_VALID', '%s не является допустимым SQL!');
define('_AM_SYSTEM_MODULES_GROUP_ID', ' Группа ID: %s ');
define('_AM_SYSTEM_MODULES_NAME', ' Имя: ');
define('_AM_SYSTEM_MODULES_VALUE', ' Оценка: ');
// Templates
define('_AM_SYSTEM_MODULES_TEMPLATES_ADD', 'Добавление шаблонов...');
define('_AM_SYSTEM_MODULES_TEMPLATES_DELETE', 'Удаление шаблонов...');
define('_AM_SYSTEM_MODULES_TEMPLATES_UPDATE', 'Обновление шаблонов...');
define('_AM_SYSTEM_MODULES_TEMPLATE_ID', 'Шаблон ID: %s ');
define('_AM_SYSTEM_MODULES_TEMPLATE_ADD_DATA', 'Шаблон %s добавлен в базу данных.');
define('_AM_SYSTEM_MODULES_TEMPLATE_ADD_ERROR', 'ОШИБКА: Не удалось установить шаблон %s в базу данных.');
define('_AM_SYSTEM_MODULES_TEMPLATE_COMPILED', 'Шаблон %s скомпилирован ');
define('_AM_SYSTEM_MODULES_TEMPLATE_COMPILED_FAILED', 'ОШИБКА: Ошибка компиляции шаблона %s ');
define('_AM_SYSTEM_MODULES_TEMPLATE_DELETE_DATA', 'Шаблон %s удален из базы данных. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_DELETE_DATA_FAILD', 'ОШИБКА: Не удалось удалить шаблон %s из базы данных. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_INSERT_DATA', 'Шаблон %s устанавливается в базу данных. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_RECOMPILE', 'Шаблон %s перекомпилирован');
define('_AM_SYSTEM_MODULES_TEMPLATE_RECOMPILE_FAILD', 'ОШИБКА: Шаблон %s перекомпилировать не удалось');
define('_AM_SYSTEM_MODULES_TEMPLATE_RECOMPILE_ERROR', 'ОШИБКА: Не удалось пересобрать шаблон %s ');
define('_AM_SYSTEM_MODULES_TEMPLATE_DELETE_OLD_ERROR', 'ОШИБКА: Не удалось удалить старый шаблон %s.  Прекращено обновление этого файла. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_UPDATE', 'Шаблон %s обновлен. ');
define('_AM_SYSTEM_MODULES_TEMPLATE_UPDATE_ERROR', 'ОШИБКА: Не удалось обновить %s шаблон. ');
// Blocks
define('_AM_SYSTEM_MODULES_BLOCKS_ADD', 'Добавление блоков...');
define('_AM_SYSTEM_MODULES_BLOCKS_DELETE', 'Удаление блока...');
define('_AM_SYSTEM_MODULES_BLOCKS_REBUILD', 'Перестроение блоков...');
define('_AM_SYSTEM_MODULES_BLOCK_ID', ' Блок ID: %s ');
define('_AM_SYSTEM_MODULES_BLOCK_ACCESS', 'Добавлен блок прав доступа');
define('_AM_SYSTEM_MODULES_BLOCK_ACCESS_ERROR', 'ОШИБКА: Не удалось добавить блок доступа');
define('_AM_SYSTEM_MODULES_BLOCK_ADD', 'Блок %s добавлен ');
define('_AM_SYSTEM_MODULES_BLOCK_ADD_ERROR', 'ОШИБКА: Не удалось добавить блок %s в базу данных! ');
define('_AM_SYSTEM_MODULES_BLOCK_ADD_ERROR_DATABASE', 'Ошибка базы данных: %s ');
define('_AM_SYSTEM_MODULES_BLOCK_CREATED', 'Блок %s создан ');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE', 'Блок %s удален. ');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE_DATA', 'Шаблон блока %s удален из базы данных. ');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE_ERROR', 'ОШИБКА: Невозможно удалить блок %s');
define('_AM_SYSTEM_MODULES_BLOCK_DELETE_TEMPLATE_ERROR', 'ОШИБКА: Невозможно удалить шаблон блока %s из базы данных');
define('_AM_SYSTEM_MODULES_BLOCK_DEPRECATED', 'Блок шаблона %s осуждается ');
define('_AM_SYSTEM_MODULES_BLOCK_DEPRECATED_ERROR', 'ОШИБКА: Не удалось удалить шаблон устаревший блок.  ');
define('_AM_SYSTEM_MODULES_BLOCK_UPDATE', 'Блок %s обновлен. ');
// Configs
define('_AM_SYSTEM_MODULES_GONFIG_ID', 'Конфиг ID: %s');
define('_AM_SYSTEM_MODULES_MODULE_DATA_ADD', 'Добавление данных конфигурации модуля...');
define('_AM_SYSTEM_MODULES_MODULE_DATA_DELETE', 'Удаление параметров конфигурации модуля...');
define('_AM_SYSTEM_MODULES_MODULE_DATA_UPDATE', 'Данные модуля обновлены.');
define('_AM_SYSTEM_MODULES_CONFIG_ADD', ' Опция конфигурации добавлена');
define('_AM_SYSTEM_MODULES_CONFIG_DATA_ADD', ' Конфигурация %s добавлено в базу данных');
define('_AM_SYSTEM_MODULES_CONFIG_DATA_ADD_ERROR', ' ОШИБКА: Не удалось вставить конфигурацию %s в базу данных. ');
define('_AM_SYSTEM_MODULES_GONFIG_DATA_DELETE', 'Данные для конфигурации удалены из базы данных. ');
define('_AM_SYSTEM_MODULES_CONFIG_DATA_DELETE_ERROR', 'ОШИБКА: Невозможно удалить конфигурационные данные из базы данных');
// Access
define('_AM_SYSTEM_MODULES_GROUP_SETTINGS_ADD', 'Настройка групповых прав...');
define('_AM_SYSTEM_MODULES_GROUP_PERMS_DELETE_ERROR', 'ОШИБКА: Невозможно удалить разрешения группы ');
define('_AM_SYSTEM_MODULES_GROUP_PERMS_DELETED', 'Разрешений группы удалены ');
define('_AM_SYSTEM_MODULES_ACCESS_ADMIN_ADD', 'Добавлено право доступа администратора для ID группы %s');
define('_AM_SYSTEM_MODULES_ACCESS_ADMIN_ADD_ERROR', 'ОШИБКА: Невозможно добавить права доступа администратора для группы ID %s');
define('_AM_SYSTEM_MODULES_ACCESS_USER_ADD_ERROR', 'Добавлено право доступа пользователей для группы ID: %s');
define('_AM_SYSTEM_MODULES_ACCESS_USER_ADD_ERROR_ERROR', 'ОШИБКА: Не удалось добавить права доступа пользователя для группы ID: %s');
// execute module specific install script if any
define('_AM_SYSTEM_MODULES_FAILED_EXECUTE', 'Не удалось выполнить %s');
define('_AM_SYSTEM_MODULES_FAILED_SUCESS', '%s успешно выполнен.');
define('_AM_SYSTEM_MODULES_DELETE_ERROR', 'ОШИБКА: Невозможно удалить %s');
define('_AM_SYSTEM_MODULES_UPDATE_ERROR', 'ОШИБКА: Не удалось обновить %s');
define('_AM_SYSTEM_MODULES_DELETE_MOD_TABLES', 'Удаление таблиц модуля...');
define('_AM_SYSTEM_MODULES_COMMENTS_DELETE', 'Удаление комментариев...');
define('_AM_SYSTEM_MODULES_COMMENTS_DELETE_ERROR', 'ОШИБКА: Не удалось удалить комментарии');
define('_AM_SYSTEM_MODULES_COMMENTS_DELETED', 'Комментарии удалены');
define('_AM_SYSTEM_MODULES_NOTIFICATIONS_DELETE', 'Удаление уведомлений...');
define('_AM_SYSTEM_MODULES_NOTIFICATIONS_DELETE_ERROR', 'ОШИБКА: Невозможно удалить уведомления');
define('_AM_SYSTEM_MODULES_NOTIFICATIONS_DELETED', 'Уведомления удалены');
define('_AM_SYSTEM_MODULES_TABLE_DROPPED', 'Таблица %s испорчена!');
define('_AM_SYSTEM_MODULES_TABLE_DROPPED_ERROR', 'ОШИБКА: Невозможно удалить таблицу %s');
define('_AM_SYSTEM_MODULES_TABLE_DROPPED_FAILDED', 'ОШИБКА: Не разрешено удалить таблицу %s !');
// Tips
define('_AM_SYSTEM_MODULES_TIPS', '<ul>
<li>При установке нового модуля, не забудьте модуль настройки предпочтений, блоков и разрешений пользователям!</li>
<li>Для скрытия модуля в главном блоке меню, установите порядок 0</li>
<li>Удаляйте неиспользуемые файлы и модули с Вашего сервера, чтобы избежать проблем безопасности и сохранить Ваш сайт в безопасности.</li>
<li>Чтобы изменить порядок модулей (которые будут отражены в меню), вам просто нужно перетащить модули до нужного места.</li>
</ul>');
define('_AM_SYSTEM_MODULES_CONFIRM_TIPS', '<ul>
<li>Проверьте все модификации для Validate.</li>
</ul>');
// 2.5.7
define('_AM_SYSTEM_MODULES_INSTALL_TESTDATA', 'Добавить тестовые данные');
// 2.5.8
define('_AM_SYSTEM_MODULES_INSTALL_MORE', 'Установка дополнительных модулей');
