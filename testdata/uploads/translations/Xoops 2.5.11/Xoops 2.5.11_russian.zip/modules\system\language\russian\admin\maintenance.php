<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
//Nav
define('_AM_SYSTEM_MAINTENANCE_NAV_MANAGER', 'Обслуживание');
define('_AM_SYSTEM_MAINTENANCE_NAV_LIST', 'Все работы по техобслуживанию');
define('_AM_SYSTEM_MAINTENANCE_NAV_DUMP', 'Dump');
define('_AM_SYSTEM_MAINTENANCE_SESSION', 'Очистить таблицу сессий');
define('_AM_SYSTEM_MAINTENANCE_SESSION_OK', 'Сессия обслуживание : OK');
define('_AM_SYSTEM_MAINTENANCE_SESSION_NOTOK', 'Сессия обслуживание : Ошибка');
define('_AM_SYSTEM_MAINTENANCE_AVATAR', 'Удалять неиспользуемые пользовательские аватары');
define('_AM_SYSTEM_MAINTENANCE_CACHE', 'Очистить папку кэша');
define('_AM_SYSTEM_MAINTENANCE_CACHE_OK', 'Обслуживание кэша : OK');
define('_AM_SYSTEM_MAINTENANCE_CACHE_NOTOK', 'Обслуживание кэша : Ошибка');
define('_AM_SYSTEM_MAINTENANCE_TABLES', 'Обслуживание таблиц');
define('_AM_SYSTEM_MAINTENANCE_TABLES_OK', 'Обслуживание таблиц : OK');
define('_AM_SYSTEM_MAINTENANCE_TABLES_NOTOK', 'Обслуживание таблиц : Ошибка');
define('_AM_SYSTEM_MAINTENANCE_QUERY_DESC', 'Оптимизация, проверка, ремонт и анализ таблиц');
define('_AM_SYSTEM_MAINTENANCE_QUERY_OK', 'Обслуживание базы данных : OK');
define('_AM_SYSTEM_MAINTENANCE_QUERY_NOTOK', 'Обслуживание базы данных : Ошибка');
define('_AM_SYSTEM_MAINTENANCE_CHOICE1', 'Оптимизация таблиц(ы)');
define('_AM_SYSTEM_MAINTENANCE_CHOICE2', 'Проверить таблицу(ы)');
define('_AM_SYSTEM_MAINTENANCE_CHOICE3', 'Ремонт таблиц(ы)');
define('_AM_SYSTEM_MAINTENANCE_CHOICE4', 'Анализ таблиц(ы)');
define('_AM_SYSTEM_MAINTENANCE_TABLES_DESC', 'Анализ таблиц(ы) - анализирует и сохраняет распределение ключей для таблицы. Во время анализа таблица заблокирована.<br />
Проверить таблицу(ы) - проверяет таблицу или таблицы на наличие ошибок.<br />
Оптимизация таблиц(ы) - чтобы вернуть неиспользуемое пространство и дефрагментировать файл данных.<br />
Ремонт таблиц(ы) - ремонтирует, возможно, поврежденную базу данных.');
define('_AM_SYSTEM_MAINTENANCE_RESULT', 'Результат');
define('_AM_SYSTEM_MAINTENANCE_RESULT_NO_RESULT', 'Нет результата');
define('_AM_SYSTEM_MAINTENANCE_RESULT_CACHE', 'Очистить кэш');
define('_AM_SYSTEM_MAINTENANCE_RESULT_SESSION', 'Очистить таблицы сессий');
define('_AM_SYSTEM_MAINTENANCE_RESULT_QUERY', 'Базы данных');
define('_AM_SYSTEM_MAINTENANCE_RESULT_AVATAR', 'Удалять неиспользуемые аватары');
define('_AM_SYSTEM_MAINTENANCE_ERROR_MAINTENANCE', 'Ничего не выбрано для технического обслуживания');
define('_AM_SYSTEM_MAINTENANCE_TABLES1', 'Таблицы');
define('_AM_SYSTEM_MAINTENANCE_TABLES_OPTIMIZE', 'Оптимизировать');
define('_AM_SYSTEM_MAINTENANCE_TABLES_CHECK', 'Проверить');
define('_AM_SYSTEM_MAINTENANCE_TABLES_REPAIR', 'Восстановить');
define('_AM_SYSTEM_MAINTENANCE_TABLES_ANALYZE', 'Анализировать');
//Dump
define('_AM_SYSTEM_MAINTENANCE_DUMP', 'Dump');
define('_AM_SYSTEM_MAINTENANCE_DUMP_TABLES_OR_MODULES', 'Выбор таблиц или модулей');
define('_AM_SYSTEM_MAINTENANCE_DUMP_DROP', "Добавить команду DROP TABLE IF EXISTS 'tables' в dump");
define('_AM_SYSTEM_MAINTENANCE_DUMP_OR', 'ИЛИ');
define('_AM_SYSTEM_MAINTENANCE_DUMP_AND', 'И');
define('_AM_SYSTEM_MAINTENANCE_DUMP_ERROR_TABLES_OR_MODULES', 'Вы должны выбрать таблицы или модули');
define('_AM_SYSTEM_MAINTENANCE_DUMP_NO_TABLES', 'Нет таблицы');
define('_AM_SYSTEM_MAINTENANCE_DUMP_TABLES', 'Таблицы');
define('_AM_SYSTEM_MAINTENANCE_DUMP_STRUCTURES', 'Структура');
define('_AM_SYSTEM_MAINTENANCE_DUMP_NB_RECORDS', 'Количество записей');
define('_AM_SYSTEM_MAINTENANCE_DUMP_FILE_CREATED', 'Созданный файл');
define('_AM_SYSTEM_MAINTENANCE_DUMP_RESULT', 'Результат');
define('_AM_SYSTEM_MAINTENANCE_DUMP_RECORDS', 'запись(и)');
// Tips
define('_AM_SYSTEM_MAINTENANCE_TIPS', '<ul>
<li>Вы можете сделать простое техническое обслуживание Вашей системы XOOPS: очистить кэш и сеансы таблиц, и сделать обслуживание своих таблиц</li>
</ul>');
