<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_BANNERS_MANAGEMENT', 'Управление Баннерами');
define('_BANNERS_WELCOMEBACK', 'Добро пожаловать: %s');
//define('_BANNERS_LOGGEDOUT','Записан из панели рекламы');
define('_BANNERS_LOGOUT', 'Выйти');
define('_BANNERS_LOGIN_TITLE', 'Статистика баннеров');
define('_BANNERS_LOGIN_LOGIN', 'Имя (Login) :');
define('_BANNERS_LOGIN_INCORRECT', 'Не верное имя или пароль');
define('_BANNERS_LOGIN_PASS', 'Пароль :');
define('_BANNERS_LOGIN_INFO', 'Пожалуйста, введите информацию о клиенте');
define('_BANNERS_LOGIN_OK', 'OK');
define('_BANNERS_ID', 'Баннер ID:');
define('_BANNERS_TITLE', 'Активные баннеры');
define('_BANNERS_URL', 'Изменение URL:');
define('_BANNERS_NOTHINGFOUND', 'Баннеров не найдено');
define('_BANNERS_NO', '#');
define('_BANNERS_FOW_IN', 'Отображение активных баннеров: ');
define('_BANNERS_IMP_MADE', 'Imp. Made');
define('_BANNERS_IMP_TOTAL', 'Imp. Total');
define('_BANNERS_IMP_LEFT', 'Imp. Left');
define('_BANNERS_CLICKS', 'Клики');
define('_BANNERS_PER_CLICKS', '% кликов');
define('_BANNERS_FUNCTIONS', 'Функции');
define('_BANNERS_STATS', 'Статистика Email');
define('_BANNERS_SHOWBANNER', 'Показать баннер');
define('_BANNERS_SEND_STATS', 'Отправить <a href=\'%s\' title=\'E-mail Stats\'/>статистику Email</a> для этого баннера');
define('_BANNERS_POINTS', 'Этот баннер указывает на <a href=\'%s\' title=\'\'>этот URL</a>');
define('_BANNERS_UNLIMITED', 'Неограничено');
define('_BANNERS_FINISHED', 'Баннеры с истекшим сроком действия');
define('_BANNERS_STARTED', 'Дата начала');
define('_BANNERS_ENDED', 'Дата окончания');
define('_BANNERS_MAIL_SUBJECT', 'Статистика баннера на %s');
define('_BANNERS_MAIL_MESSAGE', 'Доступная статистика для выбранного баннера на %s :\n\n\n
Имя клиента: %s\n Баннер ID: %s\n
Изображение баннера: %s\n
URL баннера: %s\n\n
Impressions Purchased: %s\n
Impressions Made: %s\n
Impressions Left: %s\n
Всего кликов: %s\n
Процент кликов: %f \n\n\n
Отчеты об ошибке: %s');
define('_BANNERS_MAIL_NOT_OK', 'Мы обнаружили ошибку отправки электронной почты. Пожалуйста, свяжитесь с веб-мастером по данному вопросу.');
define('_BANNERS_MAIL_OK', 'Имеющиеся статистические данные для выбранного баннера были отправлены на Ваш адрес электронной почты, указанный в аккаунте.');
define('_BANNERS_MAIL_ERROR', 'Нет электронной почты, связанный с клиентом %s.<br />Пожалуйста, обратитесь к администратору');
define('_BANNERS_DBUPDATED', 'Пункт изменен и база данных обнавлена');
define('_BANNERS_DBERROR', 'База данных не была обновлена ​​из-за ошибки!');
define('_BANNERS_CHANGE', 'Изменить');

define('_BANNERS_NO_LOGIN_DATA', 'Регистрационные данные не найдены');
define('_BANNERS_NO_REFERER', 'Ни один реферер не найден');
define('_BANNERS_NO_ID', 'Соответствующий ID не найден');
