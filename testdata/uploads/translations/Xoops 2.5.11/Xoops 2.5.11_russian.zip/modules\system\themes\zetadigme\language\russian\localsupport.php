<?php

$menu = array();

// sample for English  support
/*
$menu[] = array(
    'link'      => 'https://www.xoops.org',
    'title'     => 'XOOPS',
    'absolute'  => 1,
    'icon'      => XOOPS_URL . '/modules/system/themes/zetadigme/icons/xoops.png'
);

$menu[] = array(
    'link'      => 'https://www.xoops.org',
    'title'     => 'XOOPS',
    'absolute'  => 1,
    'icon'      => XOOPS_URL . '/modules/system/themes/zetadigme/icons/xoops.png'
);

$menu[] = array(
    'link'      => 'https://www.xoops.org/modules/library/',
    'title'     => _AD_XOOPSTHEMES,
    'absolute'  => 1,
    'icon'      => XOOPS_URL . '/modules/system/themes/zetadigme/icons/tweb.png'
);

$menu[] = array(
    'link'      => 'https://github.com/XoopsModules25x',
    'title'     => _AD_XOOPSMODULES,
    'absolute'  => 1,
    'icon'      => XOOPS_URL . '/modules/system/themes/zetadigme/icons/xoops.png'
);
*/

return $menu;