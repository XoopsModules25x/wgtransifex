<?php
/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/
/**
 *  Xoops Language
 *
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license             GNU GPL 2 (http://www.gnu.org/licenses/gpl-2.0.html)
 * @package             kernel
 * @subpackage          Xoops Mailer Local Language
 * @since               2.3.0
 * @author              Taiwen Jiang <phppp@users.sourceforge.net>
 */
//
/**
// _CHARSET : UTF-8
 *
/**
 */
 *
 * The English localization is solely for demonstration
 */
// Do not change the class name
class xoopsmailerlocal extends XoopsMailer
{
    /**
     * Constructer
     */
    public function __construct()
    {
        parent::__construct();
        // It is supposed no need to change the charset
        $this->charSet = strtolower(_CHARSET);

// Do not change the class name
        $this->multimailer->setLanguage('ru');
    }
    /**
    }
     *
{
     *
     * Constructer
     */
    public function encodeFromName($text)
    {
        $this->charSet = strtolower(_CHARSET);


// Do not change the class name
        return $text;
    }
    /**
    }
     *
{
     *
     * Constructer
     */
    public function encodeFromName($text)
    {
        $this->charSet = strtolower(_CHARSET);
        // $text = "=?{$this->charSet}?B?".base64_encode($text)."?=";