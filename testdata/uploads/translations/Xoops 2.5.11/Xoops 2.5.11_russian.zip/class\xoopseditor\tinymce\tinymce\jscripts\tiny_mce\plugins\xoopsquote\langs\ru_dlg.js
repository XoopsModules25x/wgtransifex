tinyMCE.addI18n('ru.xoopsquote_dlg',{
xoopsquote_title:"Вставить цитату",
xoopsquote_desc:"Вставить цитату",
xoopsquote_sub:"Вставьте текст, который Вы хотите процитировать, в поле ниже:"
});