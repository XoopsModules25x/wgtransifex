<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AUTH_MSG_AUTH_METHOD', 'используя метод проверки подлинности %s ');
define('_AUTH_LDAP_EXTENSION_NOT_LOAD', 'Расширение PHP LDAP не загружено (проверьте Ваш PHP-файл конфигурации php.ini)');
define('_AUTH_LDAP_SERVER_NOT_FOUND', "Не удается подключиться к серверу");
define('_AUTH_LDAP_USER_NOT_FOUND', 'Участник %s не найден в сервере каталогов (%s) в %s');
define('_AUTH_LDAP_CANT_READ_ENTRY', "Не удается прочитать запись %s");
define('_AUTH_LDAP_XOOPS_USER_NOTFOUND', 'Sorry, no corresponding user information has been found in the XOOPS database for connection: %s <br>' . 'Please verify your user data or set on the automatic provisioning');
define('_AUTH_LDAP_START_TLS_FAILED', 'Не удалось открыть соединение TLS');
