/**
 */

tinyMCE.addI18n('ru.xoopsimagemanager',{
desc : 'Расширенный менеджер изображений Xoops',
delta_width : '0',
delta_height : '0'
});
tinyMCE.addI18n('ru.xoopsimagebrowser',{
desc : 'Менеджер изображений Xoops',
delta_width : '0',
delta_height : '0'
});