tinyMCE.addI18n('ru.example',{
desc : 'Это всего лишь кнопка шаблона'
});