<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_CAPTCHA_CAPTION', 'Код подтверждения');
define('_CAPTCHA_INVALID_CODE', 'Неверный код подтверждения!');
define('_CAPTCHA_TOOMANYATTEMPTS', 'Слишком много попыток!');
define('_CAPTCHA_MAXATTEMPTS', 'Максимальное количество попыток: %d');
// For image mode
define('_CAPTCHA_RULE_IMAGE', 'Входные буквы в изображении');
define('_CAPTCHA_RULE_CASESENSITIVE', 'Код чувствителен к регистру');
define('_CAPTCHA_RULE_CASEINSENSITIVE', 'Код не чувствительны к регистру');
define('_CAPTCHA_REFRESH', 'Нажмите, чтобы обновить изображение, если оно недостаточно ясно.');
// For text mode
define('_CAPTCHA_RULE_TEXT', 'Введите результат из выражения');

/**
 * Error defines
 */
define('_CAPTCHA_LOADFILEERROR', 'Ошибка: Не удалось загрузить файл %u в файле %s на линии %s. ');
