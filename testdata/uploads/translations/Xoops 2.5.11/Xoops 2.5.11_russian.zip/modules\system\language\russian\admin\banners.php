<?php
/**
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license         GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * _LANGCODE    en
 * _CHARSET     UTF-8
 */
//%%%%%%        Admin Module Name  Banners         %%%%%
define('_AM_SYSTEM_BANNERS_DBUPDATED', _AM_SYSTEM_DBUPDATED);
//Nav
define('_AM_SYSTEM_BANNERS_NAV_MANAGER', 'Управление баннерами');
define('_AM_SYSTEM_BANNERS_NAV_MAIN', 'Баннеры и список клиентов');
define('_AM_SYSTEM_BANNERS_NAV_EDITBNR', 'Редактировать баннеры');
define('_AM_SYSTEM_BANNERS_NAV_DELETEBNR', 'Удалить баннер');
define('_AM_SYSTEM_BANNERS_NAV_DELETEFINISHBNR', 'Удалить финишный баннер');
define('_AM_SYSTEM_BANNERS_NAV_ADDBNR', 'Добавить новый баннер');
define('_AM_SYSTEM_BANNERS_NAV_EDITADVCLI', 'Редактировать рекламного клиента');
define('_AM_SYSTEM_BANNERS_NAV_ADDNWCLI', 'Добавление нового клиента');
define('_AM_SYSTEM_BANNERS_NAV_DELETECLI', 'Удалить клиента');
define('_AM_SYSTEM_BANNERS_CURACTBNR', 'Текущие активные баннеры');
define('_AM_SYSTEM_BANNERS_BANNERID', 'Баннер ID');
define('_AM_SYSTEM_BANNERS_IMPRESION', 'Показы');
define('_AM_SYSTEM_BANNERS_IMPLEFT', 'Imp. Left');
define('_AM_SYSTEM_BANNERS_CLICKS', 'Клики');
define('_AM_SYSTEM_BANNERS_NCLICKS', '% кликов');
define('_AM_SYSTEM_BANNERS_CLINAME', 'Имя клиента');
define('_AM_SYSTEM_BANNERS_FUNCTION', 'Функции');
define('_AM_SYSTEM_BANNERS_UNLIMIT', 'Неограничено');
define('_AM_SYSTEM_BANNERS_VIEW', 'Вид баннера');
define('_AM_SYSTEM_BANNERS_EDIT', 'Редактировать');
define('_AM_SYSTEM_BANNERS_DELETE', 'Удалить');
define('_AM_SYSTEM_BANNERS_FINISHBNR', 'Готовые баннеры');
define('_AM_SYSTEM_BANNERS_IMPD', 'Imp.');
define('_AM_SYSTEM_BANNERS_STARTDATE', 'Дата начала');
define('_AM_SYSTEM_BANNERS_ENDDATE', 'Дата завершения');
define('_AM_SYSTEM_BANNERS_ADVCLI', 'Реклама клиентов');
define('_AM_SYSTEM_BANNERS_ACTIVEBNR', 'Активные баннеры');
define('_AM_SYSTEM_BANNERS_CONTNAME', 'Имя контакта');
define('_AM_SYSTEM_BANNERS_CONTMAIL', 'Email контакта');
define('_AM_SYSTEM_BANNERS_CLINAMET', 'Контактное лицо:');
define('_AM_SYSTEM_BANNERS_ADDNWBNR', 'Добавить новый баннер');
define('_AM_SYSTEM_BANNERS_IMPPURCHT', 'Куплено показов:');
define('_AM_SYSTEM_BANNERS_IMGURLT', 'URL изображения:');
define('_AM_SYSTEM_BANNERS_CLICKURLT', 'Кликов URL:');
define('_AM_SYSTEM_BANNERS_ADDBNR', 'Добавить баннер');
define('_AM_SYSTEM_BANNERS_ADDNWCLI', 'Добавление нового клиента');
define('_AM_SYSTEM_BANNERS_CONTNAMET', 'Контактное лицо:');
define('_AM_SYSTEM_BANNERS_CONTMAILT', 'Email контакта:');
define('_AM_SYSTEM_BANNERS_CLILOGINT', 'Логин клиента:');
define('_AM_SYSTEM_BANNERS_CLIPASST', 'Пароль клиента:');
define('_AM_SYSTEM_BANNERS_ADDCLI', 'Добавить клиента');
define('_AM_SYSTEM_BANNERS_DELEBNR', 'Удалить баннер');
define('_AM_SYSTEM_BANNERS_SUREDELE', 'Вы уверены, удалить этот баннер?');
define('_AM_SYSTEM_BANNERS_NO', 'Нет');
define('_AM_SYSTEM_BANNERS_YES', 'Да');
define('_AM_SYSTEM_BANNERS_EDITBNR', 'Редактировать баннер');
define('_AM_SYSTEM_BANNERS_ADDIMPT', 'Добавить больше показов:');
define('_AM_SYSTEM_BANNERS_PURCHT', 'Куплено:');
define('_AM_SYSTEM_BANNERS_MADET', 'Сделал:');
define('_AM_SYSTEM_BANNERS_CHGBNR', 'Изменить баннер');
define('_AM_SYSTEM_BANNERS_DELEADC', 'Удалить рекламного клиента');
define('_AM_SYSTEM_BANNERS_SUREDELCLI', 'Вы собираетесь удалить клиента <strong>%s</strong> и все баннеры !!!');
define('_AM_SYSTEM_BANNERS_NOBNRRUN', "Клиент не имеет никаких баннеров, работающих в настоящее время.");
define('_AM_SYSTEM_BANNERS_WARNING', 'ПРЕДУПРЕЖДЕНИЕ!!!');
define('_AM_SYSTEM_BANNERS_ACTBNRRUN', 'Этот клиент имеет следующие активные баннеры, работающие на нашем сайте:');
define('_AM_SYSTEM_BANNERS_SUREDELBNR', 'Вы уверены, что хотите удалить этого клиента и все его баннеры?');
define('_AM_SYSTEM_BANNERS_EDITADVCLI', 'Редактировать рекламного клиента');
define('_AM_SYSTEM_BANNERS_EXTINFO', 'Дополнительная информация:');
define('_AM_SYSTEM_BANNERS_CHGCLI', 'Изменение клиента');
define('_AM_SYSTEM_BANNERS_USEHTML', 'Использовать HTML-код?');
define('_AM_SYSTEM_BANNERS_CODEHTML', 'Введите HTML-код:');
// Tips
define('_AM_SYSTEM_BANNERS_NAV_TIPS', '
<ul>
<li>Добавление, изменение и обновление категорий, баннеров и клиентов.</li>
</ul>
');
