tinyMCE.addI18n('en.xoopsquote',{
    quote_desc:"Insert quote"
});