tinyMCE.addI18n('en.xoopscode_dlg',{
    xoopscode_title:"Insert code",
    xoopscode_desc:"Insert code",
    xoopscode_sub:"Paste the code you want to insert in the box below:"
});