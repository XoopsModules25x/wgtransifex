/**
 */

tinyMCE.addI18n('en.xoopsemotions_dlg',{
    title : 'Insert Xoops Emoticons',
    tab_emotionsbrowser: 'Emoticons',
    tab_emotionsadmin: 'Add Emoticons',
    error_noemotions: 'No emotions in database !!!'
});