<?php

define('_AM_XMF_MODULE_NOTFOUND','Please install or reactivate %1$s module. Minimum version required: %2$s');
define('_AM_XMF_MODULE_VERSION','Minimum %1$s module version required: %2$s (your version is %3$s)');
define('_AM_XMF_MODULE_INSTALLED', 'The module \'%s\' is installed!');
define('_AM_XMF_MODULE_NOT_INSTALLED', 'The module \'%s\' is not installed!');

define('_DB_XMF_TABLE_IS_NOT_DEFINED','Table is not defined');
