<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_XO_ER_FILENOTFOUND','Requested file: <b>%s</b> was not found ');
define('_XO_ER_CLASSNOTFOUND','Requested class %s was not found');
