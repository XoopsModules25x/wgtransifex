/**
 */

tinyMCE.addI18n('en.xoopsimagemanager',{
    desc : 'Xoops Advanced Imagemanager',
    delta_width : '0',
    delta_height : '0'
});
tinyMCE.addI18n('en.xoopsimagebrowser',{
    desc : 'Xoops Imagebrowser',
    delta_width : '0',
    delta_height : '0'
});