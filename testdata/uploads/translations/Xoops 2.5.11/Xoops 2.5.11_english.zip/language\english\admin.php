<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AD_NORIGHT', 'You don\'t have the permission to access this area');
define('_AD_ACTION', 'Action');
define('_AD_EDIT', 'Edit');
define('_AD_DELETE', 'Delete');
define('_AD_LASTTENUSERS', 'Last 10 registered users');
define('_AD_NICKNAME', 'Username');
define('_AD_EMAIL', 'Email');
define('_AD_AVATAR', 'Avatar');
define('_AD_REGISTERED', 'Registered'); //Registered Date
// define('_AD_PRESSGEN','This is your first time to enter the administration section. Press the button below to proceed.');
define('_AD_LOGINADMIN', 'Logging you in..');
define('_AD_WARNINGINSTALL', 'WARNING: Directory %s exists on your server. <br>Please remove this directory for security reasons.');
define('_AD_WARNINGWRITEABLE', 'WARNING: File %s is writeable by the server. <br>Please change the permission of this file for security reasons.<br> in Unix (444), in Win32 (read-only)');
define('_AD_WARNINGNOTWRITEABLE', 'WARNING: Folder %s is not writeable by the server. <br>Please change the permission of this folder.<br> in Unix (777), in Win32 (writable)');
define('_AD_WARNINGXOOPSLIBINSIDE', 'WARNING: Folder %s is inside DocumentRoot! <br>For security considerations it is highly suggested to move it out of DocumentRoot.');
define('_AD_WARNING_OLD_PHP', 'WARNING: Consider upgrading to a newer version of PHP. Version %s or newer is recommended and will be required in future XOOPS versions.');