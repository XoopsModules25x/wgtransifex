tinyMCE.addI18n('en.xoopsquote_dlg',{
    xoopsquote_title:"Insert quote",
    xoopsquote_desc:"Insert quote",
    xoopsquote_sub:"Paste the text you want to quote in the box below:"
});