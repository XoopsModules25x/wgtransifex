<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PM_AM_PRUNE', 'Prune');
define('_PM_AM_PRUNEAFTER', 'Prune messages posted after this date (leave blank for no start date)');
define('_PM_AM_PRUNEBEFORE', 'Prune messages posted before this date (leave blank for no end date)');
define('_PM_AM_ONLYREADMESSAGES', 'Prune only read messages');
define('_PM_AM_INCLUDESAVE', "Include messages in users' \"save\" folders");
define('_PM_AM_NOTIFYUSERS', 'Notify affected users about the prune?');
define('_PM_AM_MESSAGESPRUNED', '%u Messages Pruned');
define('_PM_AM_ERRORWHILEPRUNING', 'An error occurred during prune');
