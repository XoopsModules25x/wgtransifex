<?php

define('_AM_XMF_MODULE_NOTFOUND','Bitte Modul %1$s installieren oder reaktivieren. Erforderliche Minimalversion: %2$s');
define('_AM_XMF_MODULE_VERSION','Erforderliche Minimalversion für Modul %1$s ist:  %2$s (Ihre aktuelle Version ist %3$s)');
define('_AM_XMF_MODULE_INSTALLED', 'Das Modul \'%s\' ist installiert!');
define('_AM_XMF_MODULE_NOT_INSTALLED', 'Das Modul \'%s\' ist nicht installiert!');

define('_DB_XMF_TABLE_IS_NOT_DEFINED','Tabelle ist nicht definiert');
