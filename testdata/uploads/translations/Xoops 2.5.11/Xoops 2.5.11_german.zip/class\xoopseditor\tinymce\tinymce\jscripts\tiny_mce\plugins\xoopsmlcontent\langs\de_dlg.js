/**
 */

tinyMCE.addI18n('de.xoopsmlcontent_dlg',{
title : 'Einf\u00fcgen von mehrschrachlichen Content',
subtitle : 'W\u00e4hle die Sprache aus und f\u00fcge den Text in unteres Feld ein:',
sellang : 'Sprache ausw\u00e4hlen',
chooselang : 'Bitte eine Sprache ausw\u00e4hlen',
maxstring : ' Zeichen von %maxchar% verwendet',
alertmaxstring : 'Die maximale Anzahl an Zeichen erreicht',
    delta_width : 100,
    delta_height : 100
});