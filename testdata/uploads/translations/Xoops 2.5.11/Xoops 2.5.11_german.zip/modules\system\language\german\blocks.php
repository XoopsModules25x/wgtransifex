<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
// Blocks
define('_MB_SYSTEM_ADMENU', 'Administration');
define('_MB_SYSTEM_RNOW', 'Registrieren');
define('_MB_SYSTEM_LPASS', 'Passwort vergessen?');
define('_MB_SYSTEM_SEARCH', 'Suche');
define('_MB_SYSTEM_ADVS', 'Erweiterte Suche');
define('_MB_SYSTEM_VACNT', 'Konto');
define('_MB_SYSTEM_EACNT', 'Konto bearbeiten');
// RMV-NOTIFY
define('_MB_SYSTEM_NOTIF', 'Benachrichtigungen');
define('_MB_SYSTEM_LOUT', 'Abmelden');
define('_MB_SYSTEM_INBOX', 'Posteingang');
define('_MB_SYSTEM_SUBMS', 'Übermittelte Artikel');
define('_MB_SYSTEM_WLNKS', 'Übermittelte Links');
define('_MB_SYSTEM_BLNK', 'Defekte Links');
define('_MB_SYSTEM_MLNKS', 'Veränderte Links');
define('_MB_SYSTEM_WDLS', 'Übermittelte Downloads');
define('_MB_SYSTEM_BFLS', 'Defekte Downloads');
define('_MB_SYSTEM_MFLS', 'Änderungen Downloads');
define('_MB_SYSTEM_TDMDOWNLOADS', 'Übermittelte Downloads');
define('_MB_SYSTEM_EXTGALLERY', 'Übermittelte Fotos');
define('_MB_SYSTEM_SMARTSECTION', 'Artikel');
define('_MB_SYSTEM_HOME', 'Home'); // link to home page in main menu block
define('_MB_SYSTEM_RECO', 'Empfehlen Sie uns weiter.');
define('_MB_SYSTEM_PWWIDTH', 'Pop-Up-Fenster - Breite');
define('_MB_SYSTEM_PWHEIGHT', 'Pop-Up-Fenster - Höhe');
define('_MB_SYSTEM_LOGO', 'Logo-Datei im Verzeichnis %s');  // %s is your root image directory name
define('_MB_SYSTEM_COMPEND', 'Kommentare');
//define('_MB_SYSTEM_LOGGEDINAS',"Eingeloggt als");
define('_MB_SYSTEM_SADMIN', 'Admin-Gruppe einsehen');
define('_MB_SYSTEM_SPMTO', 'Private Nachricht an %s senden');
define('_MB_SYSTEM_SEMTO', 'Sende Email an %s');
define('_MB_SYSTEM_DISPLAY', 'Zeige %s Mitglieder an');
define('_MB_SYSTEM_DISPLAYA', 'Mitgliedsavatare anzeigen');
define('_MB_SYSTEM_NODISPGR', 'Zeige keine Mitglieder an die folgenden Rang haben:');
define('_MB_SYSTEM_DISPLAYC', 'Zeige %s Kommentare an');
define('_MB_SYSTEM_SECURE', 'Sicheres Einloggen');
define('_MB_SYSTEM_NUMTHEME', '%s Themen');
define('_MB_SYSTEM_THSHOW', 'Zeige Screenshot an');
define('_MB_SYSTEM_THWIDTH', 'Screenshot-Breite');
define('_MB_SYSTEM_REMEMBERME', 'Eingeloggt bleiben?');
//2.5.8
define('_MB_SYSTEM_BLOCK_HEIGHT', 'Block Höhe (Zeilen)');
