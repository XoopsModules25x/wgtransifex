/**
 */

tinyMCE.addI18n('de.xoopsimagemanager',{
    desc : 'Xoops erweiterter Bildmanager',
    delta_width : '0',
    delta_height : '0'
});
tinyMCE.addI18n('de.xoopsimagebrowser',{
    desc : 'Xoops Bild-Browser',
    delta_width : '0',
    delta_height : '0'
});