/**
 */

tinyMCE.addI18n('de.xoopsmlcontent',{
desc : 'Einf\u00fcgen von mehrschrachlichen Content',
    delta_width : '0',
    delta_height : '0'
});