<?php
/**
 * Adapted from the following under GPL 1 or greater license
 * http://search.cpan.org/~creamyg/Lingua-StopWords-0.09/
 */
define(
    '_XMF_STOPWORDS',
"aber alle allem allen aller alles als also am an ander andere anderem anderen anderer anderes anderm andern anders auch auf aus bei bin bis "
. "bist da dadurch daher damit dann darum das daß dass dasselbe dazu dein deine deinem deinen deiner deines dem demselben den denn denselben der "
. "derer derselbe derselben des deshalb desselben dessen dich die dies diese dieselbe dieselben diesem diesen dieser dieses dir doch dort du "
. "durch ein eine einem einen einer eines einig einige einigem einigen einiger einiges einmal er es etwas euch euer eure eurem euren eurer "
. "eures fuer für gegen gewesen hab habe haben haette haetten hat hatte hätte hatten hätten hattest hattet hier hin hinter ich ihm ihn ihnen "
. "ihr ihre ihrem ihren ihrer ihres im in indem ins ist ja jede jedem jeden jeder jedes jene jenem jenen jener jenes jetzt kann kannst kein keine "
. "keinem keinen keiner keines koennen koennnte können könnt könnte machen man manche manchem manchen mancher manches mein meine meinem meinen "
. "meiner meines meist meistens mich mir mit muß muss müssen mußt musst müßt muesst muesste muesten musste nach nachdem nein nicht nichts noch nun "
. "nur ob oder ohne sehr seid sein seine seinem seinen seiner seines selbst sich sie sind so solche solchem solchen solcher solches soll sollen sollst "
. "sollt sollte sollten solltest sondern sonst soweit sowie über ueber um "
. "und uns unse unsem unsen unser unsere unses unter viel vom von vor waehrend "
. "waere waeren waerst während wann war wäre waren wären warst wärst warum "
. "was weg weil weiter weitere welche welchem welchen welcher welches wenn "
. "wer werde werden werdet weshalb wie wieder wieso will wir wird wirst wo "
. "woher wohin wollen wollte wollten wolltest wuerde wuerden wuerdest würde "
. "würden würdest wurde wurden wurdest zu zum zur zwar zwischen"
);