<?php
define('_MD_PROTECTOR_YOUAREBADIP', 'Diese IP wurden als Böse-IP vom Protector registriert.<br>');
define('_MD_PROTECTOR_FMT_JAILINFO', 'Diese Einschränkung verfällt am %s');
define('_MD_PROTECTOR_FMT_JAILTIME', 'd.m.Y H:i:s');
define('_MD_PROTECTOR_BANDWIDTHLIMITED', 'Die Webseite ist derzeit überlastet, bitte versuchen Sie es später erneut.');
define('_MD_PROTECTOR_TURNJAVASCRIPTON', 'JavaScript einschalten');
define('_MD_PROTECTOR_DENYBYRBL', 'Protector hat den Beitrag gesperrt, da die verwendete IP auf der Ausschlussliste steht');
define('_MD_PROTECTOR_FMT_REGISTER_MORATORIUM', 'Bitte nochmals in %s Minuten versuchen. (wegen Anti-SPAMMING, sorry)');
