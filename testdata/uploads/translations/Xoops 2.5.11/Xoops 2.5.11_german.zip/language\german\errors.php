<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_XO_ER_FILENOTFOUND','Die angegebene Datei: <b>%s</b> wurde nicht gefunden ');
define('_XO_ER_CLASSNOTFOUND','Die angegebene Klasse %s wurde nicht gefunden');
