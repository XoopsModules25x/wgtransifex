<?php
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_CONFIRM_UPGRADE_220', "
Das Upgrade-Script wird die Daten vom Modul 'Profile' migrieren.<br>
Bitte deinstallieren Sie das Modul 'Profile' nicht vorher, da sonst die dazugehörigen Daten nicht mehr migriert werden.<br><br>Wenn der Upgradeprozess abgeschlossen ist <strong>dann gehen Sie zur Modulverwaltung und updaten Sie das Modul 'Profile'</strong>. Wenn dies erledigt ist, dann sind alle Profildaten komplett migriert.<br><br>Wenn Sie das Upgrade abbrechen wollen, dann <a href='index.php'>klicken Sie hier</a>.<br><br>oder Sie <a style='color:green; font-size:1.3em;' href='index.php?action=next&upd220=ok'>setzen fort</a>.
");
