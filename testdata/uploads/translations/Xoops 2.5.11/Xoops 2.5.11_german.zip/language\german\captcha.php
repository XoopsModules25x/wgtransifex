<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_CAPTCHA_CAPTION', 'Bestätigungscode');
define('_CAPTCHA_INVALID_CODE', 'Ungültiger Bestätigungscode!');
define('_CAPTCHA_TOOMANYATTEMPTS', 'Zu viele Versuche!');
define('_CAPTCHA_MAXATTEMPTS', 'Sie haben max. %d Versuche.');
// For image mode
define('_CAPTCHA_RULE_IMAGE', 'Geben Sie die Zeichen aus dem Bild ein');
define('_CAPTCHA_RULE_CASESENSITIVE', 'Es wird zwischen Groß und Kleinschreibung unterschieden');
define('_CAPTCHA_RULE_CASEINSENSITIVE', 'Es wird nicht zwischen Groß und Kleinschreibung unterschieden');
define('_CAPTCHA_REFRESH', 'Zum neu Laden auf das Bild klicken.');
// For text mode
define('_CAPTCHA_RULE_TEXT', 'Geben Sie die Zeichenfolge aus dem Bild ein');

/**
 * Error defines
 */
define('_CAPTCHA_LOADFILEERROR', 'FEHLER: Kann Datei %u aus der Datei %s nicht laden. Fehler in Zeile %s.');
