<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AUTH_MSG_AUTH_METHOD', 'Benutzte Authentifizierungsmethode: %s');
define('_AUTH_LDAP_EXTENSION_NOT_LOAD', 'PHP LDAP Erweiterung nicht geladen (überprüfen Sie die php-Konfigurationsdatei php.ini)');
define('_AUTH_LDAP_SERVER_NOT_FOUND', "Keine Verbindung zum Server möglich");
define('_AUTH_LDAP_USER_NOT_FOUND', 'Der Benutzer %s wurde im Verzeichnis-Server nicht gefunden (%s) in %s');
define('_AUTH_LDAP_CANT_READ_ENTRY', "Eintrag %s kann nicht gelesen werden");
define('_AUTH_LDAP_XOOPS_USER_NOTFOUND', 'Sorry, no corresponding user information has been found in the XOOPS database for connection: %s <br>' . 'Please verify your user data or set on the automatic provisioning');
define('_AUTH_LDAP_START_TLS_FAILED', 'Fehler beim Öffnen einer TLS Verbindung');
