tinyMCE.addI18n('de.xoopscode',{
    code_desc:"Code einf\u00fcgen"
});