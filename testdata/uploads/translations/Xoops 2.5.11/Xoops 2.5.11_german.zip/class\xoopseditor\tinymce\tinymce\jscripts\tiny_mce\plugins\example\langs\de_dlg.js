tinyMCE.addI18n('de.example_dlg',{
title : 'Das ist ein Titel Beispiel'
});