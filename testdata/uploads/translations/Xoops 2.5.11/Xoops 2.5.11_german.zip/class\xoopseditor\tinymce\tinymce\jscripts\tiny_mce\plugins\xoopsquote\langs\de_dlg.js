tinyMCE.addI18n('de.xoopsquote_dlg',{
xoopsquote_title:"Zitat einf\u00fcgen",
xoopsquote_desc:"Zitat einf\u00fcgen",
xoopsquote_sub:"Schreiben den Text der zitiert werden soll in unten stehendes Feld:"
});