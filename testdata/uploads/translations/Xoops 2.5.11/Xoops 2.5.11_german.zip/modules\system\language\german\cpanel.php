<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_MD_AM_VRSN', 'Version');
define('_MD_AM_FINDUSER', 'Mitglieder suchen');
define('_MD_CPANEL_NEWS', 'Artikel');
define('_MD_CPANEL_NEWS_DESC', 'XOOPS Entwicklungsnewsews');
define('_MD_CPANEL_PROJECT', 'Projekt');
define('_MD_CPANEL_PROJECT_DESC', 'XOOPS Projekt Website');
define('_MD_CPANEL_COMMUNITY', 'Community');
define('_MD_CPANEL_COMMUNITY_DESC', 'XOOPS Official Community Website');
define('_MD_CPANEL_LOCAL', 'Local Support');
define('_MD_CPANEL_LOCAL_DESC', 'XOOPS Certified Local Support websites');
define('_MD_CPANEL_OVERVIEW', 'Systemübersicht');
define('_MD_CPANEL_PHPEXTENSIONS', 'Geladene PHP Extensions');
define('_MD_CPANEL_VERSION', '%s Version');
define('_MD_CPANEL_QUICKLINKS', 'Quick Links');
define('_MD_CPANEL_SITE_ADMINISTRATION', '%s Administration');
// for help page
define('_MD_CPANEL_HELPCENTER', 'Willkommen im XOOPS Hilfe-Center');
