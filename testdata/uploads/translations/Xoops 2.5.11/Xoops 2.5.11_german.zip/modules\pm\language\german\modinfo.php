<?php
// 
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team
define('_PM_MI_NAME', 'Private Nachrichten');
define('_PM_MI_DESC', 'Modul zum Versand von privaten Nachrichten zwischen Usern');
define('_PM_MI_INDEX', 'Home');
define('_PM_MI_PRUNE', 'Nachrichten säubern');
define('_PM_MI_LINK_TITLE', 'PN-Link');
define('_PM_MI_LINK_DESCRIPTION', 'Zeigt einen Link an, um eine private Nachricht an einen User zu schicken');
define('_PM_MI_MESSAGE', 'Eine Nachricht schreiben an');
define('_PM_MI_PRUNESUBJECT', 'PN-Betreffzeile säubern');
define('_PM_MI_PRUNESUBJECT_DESC', 'Dies wird der Betreff der PN an den User sein nach der PM-Säuberung');
define('_PM_MI_PRUNEMESSAGE', 'PN-Body säubern');
define('_PM_MI_PRUNEMESSAGE_DESC', "Diese Nachricht wird der Body der Nachricht an User in deren Posteingang sein nach einer PN-Säuberung. Benutzen Sie {PM_COUNT} im Text der ausgetauscht wird durch die Anzahl der Nachrichten, die aus dem Posteingang des Users gelöscht worden sind");
define('_PM_MI_PRUNESUBJECTDEFAULT', 'Gelöschte Nachrichten nach Säuberung');
define('_PM_MI_PRUNEMESSAGEDEFAULT', 'Während der Säuberung der Privaten Nachrichten wurden {PM_COUNT} in Ihrem Posteingang gelöscht um Platz und Resourcen zu sparen');
define('_PM_MI_MAXSAVE', 'Maximale Nachrichten im Postausgang');
define('_PM_MI_MAXSAVE_DESC', '');
define('_PM_MI_PERPAGE', 'Nachrichten pro Seite');
define('_PM_MI_PERPAGE_DESC', '');
//1.07
define('_PM_MI_ABOUT', 'About');
