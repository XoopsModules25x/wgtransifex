/**
 */

tinyMCE.addI18n('de.xoopsemotions_dlg',{
    title : 'Einf\u00fcgen von Xoops Emotions',
    tab_emotionsbrowser: 'Emoticons',
    tab_emotionsadmin: 'Emoticons hinzuf\u00fcgen',
    error_noemotions: 'Keine Emotions in Datenbank !!!'
});