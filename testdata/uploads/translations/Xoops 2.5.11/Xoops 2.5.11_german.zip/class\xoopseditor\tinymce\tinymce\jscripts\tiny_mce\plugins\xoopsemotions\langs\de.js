/**
 */

tinyMCE.addI18n('de.xoopsemotions',{
    desc : 'Einf\u00fcgen von Xoops Emotions',
    delta_width : '0',
    delta_height : '0'
});