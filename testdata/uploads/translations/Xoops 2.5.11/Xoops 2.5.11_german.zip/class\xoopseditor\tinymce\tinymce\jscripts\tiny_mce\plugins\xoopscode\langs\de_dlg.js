tinyMCE.addI18n('de.xoopscode_dlg',{
    xoopscode_title:"Code einf\u00fcgen",
    xoopscode_desc:"Code einf\u00fcgen",
    xoopscode_sub:"Schreiben den Text der zitiert werden soll in unten stehendes Feld::"
});