tinyMCE.addI18n('de.xoopsquote',{
quote_desc:"Zitat einf\u00fcgen"
});