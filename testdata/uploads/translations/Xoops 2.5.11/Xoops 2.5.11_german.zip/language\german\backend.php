<?php
//
// _LANGCODE: de
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

// RSS feed URLs
return array('https://xoops.org/modules/publisher/backend.php');