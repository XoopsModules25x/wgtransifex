tinyMCE.addI18n('de.example',{
    desc : 'Das ist nur eine Vorlage Schaltfläche'
});