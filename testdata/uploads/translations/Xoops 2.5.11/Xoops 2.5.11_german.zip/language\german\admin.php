<?php
//
// _LANGCODE: en
// _CHARSET : UTF-8
// Translator: XOOPS Translation Team

define('_AD_NORIGHT', 'Sie haben nicht die Erlaubnis diesen Bereich zu betreten');
define('_AD_ACTION', 'Aktion');
define('_AD_EDIT', 'Bearbeiten');
define('_AD_DELETE', 'Löschen');
define('_AD_LASTTENUSERS', 'Die letzten 10 registrierten Benutzer');
define('_AD_NICKNAME', 'Benutzername');
define('_AD_EMAIL', 'E-Mail-Adresse');
define('_AD_AVATAR', 'Avatar');
define('_AD_REGISTERED', 'Registriert am '); //Registered Date
// define('_AD_PRESSGEN','Sie befinden sich das erste Mal im Administrationsbereich. Zum Fortsetzen klicken Sie bite auf die untere Schaltfläche. ');
define('_AD_LOGINADMIN', 'Sie werden eingeloggt..');
define('_AD_WARNINGINSTALL', 'ACHTUNG: Das Verzeichnis %s existiert auf Ihrem Server. <br>Aus Sicherheitsgründen wird empfohlen, dieses zu entfernen.');
define('_AD_WARNINGWRITEABLE', 'ACHTUNG: Die Datei %s auf Ihrem Server ist beschreibbar. <br>Aus Sicherheitsgründen wird empfohlen, die Zugriffsberechtigungen entsprechend zu ändern. <br>in Unix (444) bzw. in Win32 (read-only)');
define('_AD_WARNINGNOTWRITEABLE', 'ACHTUNG: Das Verzeichnis %s auf Ihrem Server ist nicht beschreibbar. <br>Bitte ändern Sie die Zugriffsberechtigungen entsprechend.<br> in Unix (777) bzw. in Win32 (writeable)');
define('_AD_WARNINGXOOPSLIBINSIDE', 'ACHTUNG: Das Verzeichnis %s befindet sich innerhalb des Dokument-Root!<br>Aus Sicherheitsgründen wird dringend empfohlen, dieses aus dem Root-Verzeichnis herauszunehmen bzw. in einen von außen nicht zugreifbaren Bereich zu verschieben.');
define('_AD_WARNING_OLD_PHP', 'ACHTUNG: Ein Upgrade auf der PHP-Version wird dringend empfohlen. Version %s oder neuer ist empfohlen und wird in den zukünfitgen XOOPS Versionen erforderlich sein.');